-- Run as database owner / superuser. Replace passwords using secret manager, not source code.
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='estimator_app') THEN CREATE ROLE estimator_app LOGIN PASSWORD 'REPLACE_ME'; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='estimator_migrator') THEN CREATE ROLE estimator_migrator LOGIN PASSWORD 'REPLACE_ME'; END IF; END $$;
GRANT CONNECT ON DATABASE estimator TO estimator_app,estimator_migrator;
GRANT USAGE ON SCHEMA public TO estimator_app;
GRANT USAGE,CREATE ON SCHEMA public TO estimator_migrator;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO estimator_app;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO estimator_app;
ALTER DEFAULT PRIVILEGES FOR ROLE estimator_migrator IN SCHEMA public GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO estimator_app;
ALTER DEFAULT PRIVILEGES FOR ROLE estimator_migrator IN SCHEMA public GRANT USAGE,SELECT ON SEQUENCES TO estimator_app;
-- IMPORTANT: application role must not own tables or have BYPASSRLS.
