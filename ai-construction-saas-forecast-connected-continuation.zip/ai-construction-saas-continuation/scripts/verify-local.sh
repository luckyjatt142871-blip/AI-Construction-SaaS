#!/usr/bin/env bash
set -euo pipefail
# Run from repository root, with network access, Docker Compose v2 and Node 22.
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r backend/requirements.txt
python -c 'import pyotp; print("pyotp import OK")'
(cd frontend && npm ci && npm run typecheck && npm run build)
docker compose --profile tools up -d db redis
docker compose --profile tools run --rm migrate
(cd backend && python -m pytest -q)
echo 'Browser E2E and adversarial RLS checks require their dedicated test environments.'
