#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -f package-lock.json ]; then
  echo 'package-lock.json is missing. Generating a real npm lockfile from the registry.'
  npm install --package-lock-only --ignore-scripts --no-audit --no-fund
fi
npm ci --no-audit --no-fund
