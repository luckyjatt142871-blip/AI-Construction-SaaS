# Architecture

Next.js frontend -> FastAPI -> PostgreSQL; Redis/RQ worker. All trust decisions occur on backend. Production requires external secret manager and cloud services.
