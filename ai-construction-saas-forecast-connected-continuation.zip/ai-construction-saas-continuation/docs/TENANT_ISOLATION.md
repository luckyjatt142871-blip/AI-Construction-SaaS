# Tenant Isolation

Company membership is checked server-side before project queries. A session-scoped tenant context is set for RLS. Runtime database role must never own tables or BYPASSRLS. Need actual PostgreSQL tests proving isolation and validating the SECURITY DEFINER function. No document/estimate endpoints exist in Phase 1.
