# Database

Alembic revisions 0001 and 0002. Database owner estimator_migrator differs from estimator_app runtime role in Docker. RLS is enabled for memberships, projects and audit_logs. RLS bypass, membership function search_path and grants must be tested with real PostgreSQL. Global companies/users remain a high-risk authorization boundary.
