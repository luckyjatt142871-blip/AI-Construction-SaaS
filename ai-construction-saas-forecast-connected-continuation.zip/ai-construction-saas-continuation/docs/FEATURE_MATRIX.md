# Feature matrix — 2026-10-08

Status denotes actual implementation, not intent.

| Feature | Status | Evidence / limitation |
|---|---|---|
| Authentication / MFA / RBAC | IMPLEMENTED — UNVERIFIED | Legacy backend; complete pytest blocked by missing pyotp; no live tenant integration |
| Project management | IMPLEMENTED — UNVERIFIED | Tenant-scoped endpoints and Next.js project pages; no live PostgreSQL/browser tests |
| Document upload | IMPLEMENTED — UNVERIFIED | Local private dev storage; magic bytes + image/PDF parser checks; no malware scanning or S3 |
| Image 2D takeoff | IMPLEMENTED — UNVERIFIED | Native image pixel SVG viewBox, pan/zoom, calibration and persistence; pure mapping tests pass |
| PDF page takeoff | IMPLEMENTED — UNVERIFIED | Authenticated 144-DPI raster endpoints and page selection; only page 1 may be measured until per-page calibration |
| Quantity calculations | TESTED (unit only) | Pure calculation tests passed; integration not verified |
| Cost rates / estimate / BOQ API | IMPLEMENTED — UNVERIFIED | Draft financial endpoints; no approvals/revisions/exports |
| IFC / 3D / BIM | NOT STARTED | No model import or viewer |
| 4D / 5D / AI agents | NOT STARTED | No persistent services |
| Client portal / billing / analytics | NOT STARTED | No working modules |
| Production deployment | BLOCKED | Docker, PostgreSQL, Redis, storage, security tests unverified |
