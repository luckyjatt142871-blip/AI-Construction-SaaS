# Unified roadmap
Phase 0: source, license, threat and schema audit (initial review performed; external commit pinning pending).
Phase 1: fix authentication, RLS, least privilege, storage, worker security; run real PostgreSQL/Redis/Docker and cross-tenant integration tests. **NOT APPROVED**.
Phase 2: project workflows and document intelligence (requires explicit approval).
Phase 3: 2D takeoff and manual scale calibration.
Phase 4: IFC-first BIM, licensed CAD adapters.
Phase 5: cost libraries, estimation, BOQ.
Phase 6: 4D scheduling.
Phase 7: 5D cost management.
Phase 8: constrained AI agents and validation.
Phase 9: construction management.
Phase 10: client portal, billing.
Phase 11: analytics, internationalization.
Phase 12: E2E, load, accuracy benchmarks.
Phase 13: cloud deployment and restore drills.
Phase 14: production handover.
