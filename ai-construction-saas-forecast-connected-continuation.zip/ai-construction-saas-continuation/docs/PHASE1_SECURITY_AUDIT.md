# Phase 1 security audit — 2026-10-08

## Changes in this revision
- Authentication: failed password attempts now increment a persistent counter and lock for 15 minutes after five failures; reset clears lockout and revokes sessions.
- MFA: recovery login consumes a recovery code with a database row lock, logs use, and creates a session. TOTP enable records the actual accepted time step.
- Rate limiting: separate authentication and general API fixed-window Redis counters; all API requests fail closed on Redis outage.
- HTTP: added no-store, permissions policy, and HSTS for secure-cookie deployments.
- Added static source tests. They do not replace integration tests.

## Critical unresolved security blockers
1. **PostgreSQL RLS design unsafe/incomplete**: runtime role can set `app.user_id` / `app.tenant_id`; SECURITY DEFINER function trusts those GUCs; bootstrap company creation and membership policies require redesign and live PostgreSQL testing. Do not rely on existing RLS for security.
2. **Migration owner**: Docker's `POSTGRES_USER` is superuser; migrate process uses that role. Replace with non-superuser owner and separate init administrator before production.
3. **Cross-tenant tests**: no live API+PostgreSQL integration tests for projects, members; document, estimate, and rate endpoints do not yet exist. No cross-tenant claims can be made for those modules.
4. **Private storage**: no S3 adapter, scanning, or upload/download endpoints implemented. Do not accept customer documents.
5. **Email**: synchronous SMTP delivery is not transactionally queued; verification/reset resend throttling and abuse resistance need testing.
6. **Sessions**: CSRF double-submit cookie needs origin validation and stronger deployment-specific cookie policy; session lifecycle and concurrent MFA replay need integration testing.
7. **Workers**: worker jobs lack verified tenant-scoped DB authorization.
8. **Admin**: unfinished global admin list deliberately returns 501; complete audited support access and permissions later in Phase 1.
9. **No Docker/PostgreSQL/Redis execution** in this environment. Production readiness not established.

## Verification instructions
From Windows PowerShell in repository root:

```powershell
Copy-Item .env.example .env
notepad .env
docker compose config
docker compose up -d db redis
docker compose --profile tools run --rm migrate
docker compose up --build -d api frontend worker
docker compose exec api python -m pytest -q
docker compose exec frontend npm run build
docker compose ps
docker compose logs --tail=100 api worker db redis
```

Run these on a disposable database. Existing volumes may need schema/data migration and must not be deleted if they contain customer data.
