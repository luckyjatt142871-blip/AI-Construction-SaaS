# Deployment

DO NOT DEPLOY YET. Use managed PostgreSQL, Redis with TLS, private S3, HTTPS reverse proxy, separate migration credentials, production secrets and automated backups. Never rely on the developer laptop. Production configuration remains unverified.
