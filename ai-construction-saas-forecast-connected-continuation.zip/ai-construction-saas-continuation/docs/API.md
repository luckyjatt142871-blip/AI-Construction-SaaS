# Api

Implemented endpoints: /api/auth/signup, login, login/mfa, logout, me, mfa/setup, mfa/enable, mfa/recovery/generate, verification/request, verification/confirm, password/forgot, password/reset; /api/companies and company-scoped projects/audit; /api/admin/status. /api/admin/companies returns 501 intentionally.
