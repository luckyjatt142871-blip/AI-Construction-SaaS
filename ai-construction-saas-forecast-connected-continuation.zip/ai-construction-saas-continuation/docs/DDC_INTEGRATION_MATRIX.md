# External integration assessment
| Integration | Intended use | License gate | Status |
|---|---|---|---|
| DDC Skills | estimation/document/QC methodologies | Review actual SKILL.md and dependencies | Not selected for execution |
| CWICR code | schema/semantic-search adapters | Apache-2.0 plus dependency review | Not integrated |
| CWICR data | reference rates | CC BY-NC: commercial permission needed | Blocked |
| CAD2Data scripts | CAD conversion orchestration | MIT per repo, verify per artifact | Not integrated |
| CAD2Data binaries | RVT/DWG/DGN conversion | proprietary commercial license | Blocked |
| IfcOpenShell | IFC import | verify selected package/version/license | Future Phase 4 |
