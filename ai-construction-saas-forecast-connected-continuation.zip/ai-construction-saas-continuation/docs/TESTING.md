# Testing

Run `docker compose exec api python -m pytest -q`. REQUIRED BEFORE ACCEPTANCE: two-company cross-tenant API tests, direct SQL RLS tests as estimator_app, authenticated CSRF tests, MFA replay/recovery tests, email reset expiry, admin role matrix, migration upgrade/downgrade, Redis failure modes, Docker build, frontend build, worker execution. None of these integration tests is currently verified.
