# Local Development

Windows PowerShell: `Copy-Item .env.example .env`; edit both passwords; `docker compose up -d db redis`; `docker compose --profile tools run --rm migrate`; `docker compose up --build -d api worker frontend`; `docker compose exec api python -m pytest -q`. Do not reset populated volumes.
