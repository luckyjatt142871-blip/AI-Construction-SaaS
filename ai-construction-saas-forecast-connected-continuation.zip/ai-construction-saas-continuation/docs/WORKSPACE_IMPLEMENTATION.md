# Workspace implementation — source and verification boundary

- Tenant ownership: all new business tables include `company_id`. Every new endpoint calls `member()` and checks company/project ownership, and object reads scope by company, project and object ID. Role policy currently uses `PROJECT_CREATE` for writes; fine-grained permissions need refinement.
- PostgreSQL: migration `0003` enables and forces RLS for the new tables using `app.tenant_id` set by the membership helper. Live RLS and role privilege checks have **not** been run.
- Drawings: PDF/PNG/JPEG header and 20 MiB limit; random object key, private local storage permissions, content hash, authenticated retrieval. This is not antivirus scanning and not a production S3 solution.
- Takeoff: manual point entry via an image overlay; known-distance calibration stored per drawing; deterministic area/length/count arithmetic; source drawing ID and coordinate JSON persisted; edit increments revision. Fixed-size canvas distorts image coordinates on arbitrary aspect ratios; do not use quantities commercially.
- Rates: company-scoped resource rate records with material/labour/equipment, unit, currency and provenance. No unlicensed reference dataset imported.
- Estimates: project-scoped draft, source measurement and company rate must match units/currency. Snapshot deterministic amount; BOQ endpoint returns line and total values. No approvals, rounding policy review, tax or report exports.
- External guidance: existing `docs/DDC_INTEGRATION_MATRIX.md` and `THIRD_PARTY_LICENSES.md` are advisory only; no external repository code/data integrated in this increment.
- Tests: pure calculation tests and header validation passed. All API and migration tests remain unverified due to missing dependencies/infrastructure.

## Native drawing and PDF page takeoff update

The client requests authorized `/drawings/{drawing_id}/pages/{page_number}/metadata` and `/raster` endpoints. PDF pages are rendered at fixed 144 DPI; native pixel coordinates are persisted with a `page_number`. The SVG client uses the page dimensions for its viewBox and inverse screen CTM to translate clicks under CSS resizing and zoom. Zoom/pan changes only the viewBox, never stored points.

**Limitation:** the current scale belongs to a drawing, not an individual PDF page. Measurements for PDF pages other than page 1 are blocked until page-specific calibration is implemented. Rasterization is synchronous and must be sandboxed before production. Existing local storage is development-only. Neither browser behavior nor live database migrations have been verified.
