"""Worker foundation: queues are isolated by tenant; no AI processing is implemented in Phase 1."""
import os
from redis import Redis
from rq import Worker, Queue
if __name__ == '__main__':
    conn=Redis.from_url(os.environ['REDIS_URL'])
    Worker([Queue('default',connection=conn)],connection=conn).work()
