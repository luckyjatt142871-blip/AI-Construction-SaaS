"""Contract checks for reproducible install and integration harness.

These do not substitute for executing PostgreSQL or the browser.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_backend_declares_totp_dependency():
    assert 'pyotp>=2.9,<3' in (ROOT / 'backend/requirements.txt').read_text()


def test_frontend_bootstrap_generates_real_lock_and_uses_npm_ci():
    script = (ROOT / 'frontend/install-locked.sh').read_text()
    assert 'npm install --package-lock-only' in script
    assert 'npm ci --no-audit --no-fund' in script
    assert 'package-lock.json' in script


def test_ci_runs_real_postgres_migrations_and_restricted_role_checks():
    ci = (ROOT / '.github/workflows/backend-integration.yml').read_text()
    assert 'postgres:16' in ci and 'redis:7' in ci
    assert 'alembic upgrade head' in ci
    assert 'scripts/test_rls_runtime.py' in ci
    assert 'scripts/test_migration_chain.py' in ci


def test_migration_history_is_linear_and_present():
    folder = ROOT / 'backend/alembic/versions'
    files = sorted(p for p in folder.glob('*.py') if p.name[0].isdigit())
    assert len(files) == 10
    for number, file in enumerate(files, start=1):
        assert file.name.startswith(f'{number:04d}_')
    assert 'Base.metadata.create_all' not in (folder / '0001_initial.py').read_text()
