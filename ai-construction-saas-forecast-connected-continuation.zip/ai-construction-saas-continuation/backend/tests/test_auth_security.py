from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'app/main.py').read_text()

def test_auth_source_compiles():
    ast.parse(SOURCE)

def test_recovery_code_is_deleted_before_commit():
    section=SOURCE.split("def login_recovery(",1)[1]
    assert 'with_for_update()' in section
    assert 'session.delete(code)' in section
    assert section.index('session.delete(code)') < section.index('session.commit()')

def test_lockout_and_reset_revocation_present():
    assert 'record_failed_login(session,user)' in SOURCE
    assert 'user.locked_until' in SOURCE
    assert 'delete(SessionToken)' in SOURCE

def test_fail_closed_redis_and_security_headers():
    assert "if request.url.path.startswith('/api/'):" in SOURCE
    assert "'Strict-Transport-Security'" in SOURCE
    assert "'X-CSRF-Token'" in SOURCE

def test_no_public_storage_endpoint():
    assert '/api/documents' not in SOURCE
