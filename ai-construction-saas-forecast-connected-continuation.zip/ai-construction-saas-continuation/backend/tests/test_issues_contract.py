from pathlib import Path
from app.authorization import authorized, Permission

def test_issue_schema_restricts_status_and_priority():
    source=(Path(__file__).parents[1]/"app/issue_api.py").read_text()
    assert "Literal['low','normal','high','critical']" in source
    assert "Literal['open','in_progress','resolved']" in source

def test_issue_migration_enforces_scope_and_rls():
    source=(Path(__file__).parents[1]/'alembic/versions/0010_project_issues.py').read_text()
    assert 'FORCE ROW LEVEL SECURITY' in source
    assert 'CREATE POLICY project_issues_tenant' in source
    assert 'enforce_issue_scope' in source
    assert "down_revision='0009_project_costs'" in source

def test_issue_api_scopes_reads_and_writes():
    source=(Path(__file__).parents[1]/'app/issue_api.py').read_text()
    assert 'ProjectIssue.company_id==cid' not in source or 'ProjectIssue.project_id==pid' in source
    assert 'ProjectIssue.company_id==company_id,ProjectIssue.project_id==project_id' in source
    assert 'Permission.PROJECT_CREATE' in source
