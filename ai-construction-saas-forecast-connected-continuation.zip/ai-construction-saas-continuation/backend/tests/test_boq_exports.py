from decimal import Decimal
from io import BytesIO
from app.boq_exports import export_excel, export_pdf, _total

def test_exports_contain_totals():
    from openpyxl import load_workbook
    rows = [{'item':1,'measurement_id':3,'rate_id':4,'quantity':'2.50','unit_rate':'10.00','amount':'25.00'}, {'item':2,'measurement_id':5,'rate_id':6,'quantity':'1','unit_rate':'7.25','amount':'7.25'}]
    assert _total(rows) == Decimal('32.25')
    xlsx = export_excel('Test estimate', 'USD', rows)
    wb = load_workbook(BytesIO(xlsx), read_only=True)
    assert wb.active['F5'].value == 32.25
    pdf = export_pdf('Test estimate', 'USD', rows)
    assert pdf.startswith(b'%PDF-') and len(pdf) > 1000

def test_empty_export():
    assert _total([]) == 0
    assert export_pdf('Empty', 'USD', []).startswith(b'%PDF-')
