from decimal import Decimal
from types import SimpleNamespace
from pathlib import Path
import pytest
from app.calibration_rules import calibrated_quantity

@pytest.mark.parametrize('page,rev,scale', [(1,1,'0.01'),(2,1,'0.02'),(1,2,'0.005')])
def test_distinct_page_and_revision_calibrations(page, rev, scale):
    c = SimpleNamespace(drawing_id=7, drawing_revision=rev, page_number=page, scale_m_per_pixel=Decimal(scale))
    q,unit = calibrated_quantity('length', [[0,0],[100,0]], calibration=c, drawing_id=7, drawing_revision=rev, page_number=page, width=400, height=400)
    assert q == Decimal('100') * Decimal(scale) and unit == 'm'

@pytest.mark.parametrize('bad', [float('nan'),float('inf'),-1,401])
def test_bad_coordinate_rejected(bad):
    c = SimpleNamespace(drawing_id=7, drawing_revision=1, page_number=1, scale_m_per_pixel=Decimal('0.01'))
    with pytest.raises(ValueError):
        calibrated_quantity('length', [[0,0],[bad,0]], calibration=c, drawing_id=7, drawing_revision=1, page_number=1, width=400, height=400)

def test_db_trigger_guards_cross_page_and_immutable_calibrations():
    source=(Path(__file__).resolve().parents[1]/'alembic/versions/0006_calibration_integrity.py').read_text()
    for field in ('c.company_id = NEW.company_id','c.project_id = NEW.project_id','c.drawing_id = NEW.drawing_id','c.drawing_revision = NEW.drawing_revision','c.page_number = NEW.page_number','calibration_immutable_guard'):
        assert field in source
