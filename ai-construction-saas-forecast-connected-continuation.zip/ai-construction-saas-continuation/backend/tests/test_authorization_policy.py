import pytest
from app.authorization import Permission, PERMISSIONS, authorized

@pytest.mark.parametrize('role',list(PERMISSIONS))
def test_all_roles_read_own_company_projects(role):
    assert authorized(role,Permission.PROJECT_READ,member_company_id=1,resource_company_id=1)

@pytest.mark.parametrize('role',list(PERMISSIONS))
def test_every_role_denied_cross_tenant(role):
    for permission in Permission:
        assert not authorized(role,permission,member_company_id=1,resource_company_id=2)

@pytest.mark.parametrize('role',list(PERMISSIONS))
def test_audit_access_is_admin_only(role):
    assert authorized(role,Permission.AUDIT_READ,member_company_id=1,resource_company_id=1) == (role in {'COMPANY_OWNER','COMPANY_ADMIN'})

def test_unknown_role_denied():
    assert not authorized('SUPER_ADMIN',Permission.PROJECT_READ,member_company_id=1,resource_company_id=1)
    assert not authorized(None,Permission.PROJECT_READ,member_company_id=1,resource_company_id=1)
