from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def test_rls_policy_present():
    s=(ROOT/'backend/alembic/versions/0001_initial.py').read_text()
    assert 'FORCE ROW LEVEL SECURITY' in s
    assert 'WITH CHECK' in s
def test_no_fake_payment():
    assert 'payment_success=True' not in (ROOT/'backend/app/main.py').read_text()
def test_authz_present():
    s=(ROOT/'backend/app/main.py').read_text()
    assert 'platform_guard' in s and 'member(session,user,company_id' in s
