from pathlib import Path

def test_cost_migration_scope():
    source=(Path(__file__).parents[1]/'alembic/versions/0009_project_costs.py').read_text()
    assert "down_revision='0008_project_scheduling'" in source
    assert 'FORCE ROW LEVEL SECURITY' in source
    assert 'enforce_project_cost_scope' in source

def test_cost_api_has_project_scoping():
    source=(Path(__file__).parents[1]/'app/cost_api.py').read_text()
    assert 'Project.company_id==cid' in source
    assert 'member(session,user,cid)' in source
