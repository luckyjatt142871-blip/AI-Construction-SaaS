"""Migration structure checks; live PostgreSQL trigger tests are separately required."""
from pathlib import Path

MIGRATION = Path(__file__).parents[1] / 'alembic/versions/0011_approved_estimate_guard.py'


def test_migration_chain_and_guard_operations():
    source = MIGRATION.read_text()
    assert "down_revision = '0010_project_issues'" in source
    assert 'BEFORE UPDATE OR DELETE ON estimates' in source
    assert 'BEFORE INSERT OR UPDATE OR DELETE ON estimate_lines' in source
    assert "OLD.status = 'APPROVED'" in source
    assert "parent_status = 'APPROVED'" in source
    assert 'DROP TRIGGER IF EXISTS approved_estimate_lines_guard' in source


def test_frontend_creates_company_rates_from_real_api():
    page = (Path(__file__).parents[2] / 'frontend/app/projects/[companyId]/[projectId]/estimates/page.tsx').read_text()
    assert 'Create company cost rate' in page
    assert "rate_date:rateDate" in page
    assert 'provenance' in page
    assert "'/rates`" not in page  # ensure endpoint interpolation remains intact
