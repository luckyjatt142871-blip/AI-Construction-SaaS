import pytest
from decimal import Decimal
from app.engines.quantities import (QuantityError, length, rectangle_area, rectangular_volume,
                                    polygon_area, count, apply_waste, extended_cost, SourceTrace)

def test_length_units():
    assert length('1000','mm') == Decimal('1')
    assert length('3.280839895013123','ft').quantize(Decimal('0.000001')) == Decimal('1.000000')

def test_area_volume():
    assert rectangle_area('2.5','4') == Decimal('10.0')
    assert rectangular_volume('2','3','4') == Decimal('24')

def test_polygon():
    assert polygon_area([(0,0),(4,0),(4,3),(0,3)]) == Decimal('12')
    assert polygon_area([(0,0),(0,3),(4,3),(4,0)]) == Decimal('12')

def test_reject_self_intersection():
    with pytest.raises(QuantityError): polygon_area([(0,0),(2,2),(0,2),(2,0)])

def test_reject_invalid_dimensions():
    for bad in ('0','-1','NaN','Infinity','oops'):
        with pytest.raises(QuantityError): length(bad,'m')
    with pytest.raises(QuantityError): rectangle_area(1,2,'yards')

def test_count():
    assert count(0) == 0
    for bad in (1.5, -1, True):
        with pytest.raises(QuantityError): count(bad)

def test_waste_and_cost():
    assert apply_waste('10','5') == Decimal('10.5')
    assert extended_cost('10.5','12.25') == Decimal('128.625')
    with pytest.raises(QuantityError): apply_waste('1','101')
    with pytest.raises(QuantityError): extended_cost(1,'-2')

def test_trace_required():
    assert SourceTrace(1,2,1,'R1','manual calibration',3).page == 1
    with pytest.raises(QuantityError): SourceTrace(1,2,0,'R1','manual',3)
