from decimal import Decimal
from datetime import date
from types import SimpleNamespace
import pytest
from app.engines.cost_ledger import forecast_completion

def test_forecast_arithmetic_and_provenance():
    budget=SimpleNamespace(approved_amount=Decimal('1000'),currency='USD')
    entries=[SimpleNamespace(kind='actual',amount=Decimal('200')),SimpleNamespace(kind='committed',amount=Decimal('300'))]
    f=SimpleNamespace(id=7,remaining_cost=Decimal('450'),currency='USD',source_reference='QS-2026-01',as_of=date(2026,10,8))
    result=forecast_completion(budget,entries,f)
    assert result['estimate_at_completion']=='650'
    assert result['variance_at_completion']=='350'
    assert result['estimate_to_complete']=='450'
    assert result['source_reference']=='QS-2026-01'

def test_forecast_rejects_currency_mismatch():
    with pytest.raises(ValueError):
        forecast_completion(SimpleNamespace(approved_amount=1,currency='USD'),[],SimpleNamespace(remaining_cost=1,currency='EUR'))

def test_forecast_rejects_negative_remaining():
    with pytest.raises(ValueError):
        forecast_completion(SimpleNamespace(approved_amount=1,currency='USD'),[],SimpleNamespace(remaining_cost=-1,currency='USD'))

def test_migration_contains_rls_and_scope_trigger():
    from pathlib import Path
    text=(Path(__file__).parents[1]/'alembic/versions/0013_project_cost_forecasts.py').read_text()
    assert 'FORCE ROW LEVEL SECURITY' in text
    assert 'enforce_forecast_scope' in text
    assert "down_revision='0012_project_rfis'" in text
