from pathlib import Path
import ast

SOURCE = (Path(__file__).resolve().parents[1] / "app/main.py").read_text()

def test_source_syntax():
    ast.parse(SOURCE)

def test_mfa_login_row_lock():
    section = SOURCE.split("def login_mfa(")[1].split("class TokenInput")[0]
    assert ".with_for_update()" in section
    assert "record_failed_login(session,user)" in section

def test_no_preauth_lockout_reset():
    section = SOURCE.split("def login(")[1].split("@app.post('/api/auth/logout')")[0]
    assert section.index("if user.mfa_enabled:") < section.index("user.failed_logins=0; user.locked_until=None")

def test_recovery_rotation_requires_stepup():
    section = SOURCE.split("def generate_recovery(")[1].split("class MFARecoveryLogin")[0]
    assert "ph.verify(locked.password_hash,data.password)" in section
    assert "locked.mfa_last_step=accepted" in section
    assert "session.execute(delete(MFARecovery)" in section
