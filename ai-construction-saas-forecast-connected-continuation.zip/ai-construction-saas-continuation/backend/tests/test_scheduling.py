import pytest
from app.engines.scheduling import Activity, calculate_critical_path


def test_parallel_critical_path_and_float():
    finish, results = calculate_critical_path([
        Activity('design', 3), Activity('permit', 2, ('design',)),
        Activity('procure', 6, ('design',)), Activity('build', 4, ('permit', 'procure')),
    ])
    rows = {r.id: r for r in results}
    assert finish == 13
    assert rows['build'].early_start == 9
    assert rows['permit'].total_float == 4
    assert {r.id for r in results if r.critical} == {'design', 'procure', 'build'}


def test_empty_and_milestone():
    assert calculate_critical_path([]) == (0, [])
    finish, rows = calculate_critical_path([Activity('milestone', 0)])
    assert finish == 0 and rows[0].critical


@pytest.mark.parametrize('activities', [
    [Activity('a', 1), Activity('a', 2)],
    [Activity('a', -1)],
    [Activity('a', True)],
    [Activity('a', 1, ('missing',))],
    [Activity('a', 1, ('a',))],
    [Activity('a', 1, ('b',)), Activity('b', 1, ('a',))],
    [Activity('a', 1, ('b', 'b')), Activity('b', 1)],
])
def test_reject_invalid_schedules(activities):
    with pytest.raises(ValueError):
        calculate_critical_path(activities)
