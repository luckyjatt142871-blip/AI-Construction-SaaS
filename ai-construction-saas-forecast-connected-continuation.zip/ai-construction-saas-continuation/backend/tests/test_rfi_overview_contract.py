"""Static migration/API regression contracts (not a substitute for live PostgreSQL)."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def test_rfi_input_validation_contract():
    source=(ROOT/'app/rfi_api.py').read_text()
    assert 'min_length=5' in source
    assert 'min_length=2, max_length=10000' in source
    assert "if r.status != 'open'" in source
    assert "if r.status != 'answered'" in source
def test_rfi_scope_and_audit_code():
    source=(ROOT/'app/rfi_api.py').read_text()
    assert 'ProjectRFI.company_id == company_id' in source
    assert 'ProjectRFI.project_id == project_id' in source
    assert '.with_for_update()' in source
    assert 'rfi.answered' in source and 'rfi.closed' in source
def test_rfi_migration_chain_and_rls():
    source=(ROOT/'alembic/versions/0012_project_rfis.py').read_text()
    assert "down_revision = '0011_approved_estimate_guard'" in source
    assert 'FORCE ROW LEVEL SECURITY' in source
    assert 'project_rfis_scope' in source
    assert 'enforce_rfi_scope' in source
    assert 'WITH CHECK' in source
def test_overview_uses_persisted_records():
    assert "__tablename__ = 'project_rfis'" in (ROOT/'app/rfi_models.py').read_text()
    source=(ROOT/'app/project_overview_api.py').read_text()
    assert 'func.count' in source
    assert 'mixed = any(' in source
    assert 'ProjectRFI.status' in source
