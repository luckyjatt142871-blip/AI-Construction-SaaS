"""Offline source-contract checks; live API tests require PostgreSQL and dependencies."""
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
def test_schedule_routes_registered():
    main=(BASE/'app/main.py').read_text()
    api=(BASE/'app/schedule_api.py').read_text()
    assert 'register_schedule(app, db, current_user, member, Project, AuditLog)' in main
    assert "prefix='/api/companies/{company_id}/projects/{project_id}/schedule'" in api
    assert 'calculate_critical_path' in api
    assert 'authorized(m.role' in api

def test_tenant_scoped_migration():
    ddl=(BASE/'alembic/versions/0008_project_scheduling.py').read_text()
    assert 'FORCE ROW LEVEL SECURITY' in ddl
    assert 'enforce_schedule_scope' in ddl
    assert 'predecessor_id' in ddl and 'successor_id' in ddl

def test_frontend_connected_to_schedule_api():
    page=(BASE.parent/'frontend/app/projects/[companyId]/[projectId]/schedule/page.tsx').read_text()
    assert '/schedule`' in page
    assert 'credentials:\'include\'' in page
    assert 'early_start' in page and 'critical' in page
