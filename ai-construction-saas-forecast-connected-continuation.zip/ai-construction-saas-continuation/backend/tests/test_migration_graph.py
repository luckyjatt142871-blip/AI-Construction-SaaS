"""Static revision-chain sanity check; not a substitute for live PostgreSQL migrations."""
import ast
from pathlib import Path

def test_single_linear_migration_chain():
    folder = Path(__file__).resolve().parents[1] / 'alembic' / 'versions'
    revisions = {}
    for path in folder.glob('*.py'):
        tree = ast.parse(path.read_text())
        constants = {}
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                if node.targets[0].id in ('revision', 'down_revision'):
                    constants[node.targets[0].id] = ast.literal_eval(node.value)
        assert constants['revision'] not in revisions
        revisions[constants['revision']] = constants['down_revision']
    assert len(revisions) >= 5
    assert sum(v is None for v in revisions.values()) == 1
    assert all(parent is None or parent in revisions for parent in revisions.values())
    assert set(v for v in revisions.values() if v is not None) == set(revisions) - {next(r for r in revisions if r not in revisions.values())}
