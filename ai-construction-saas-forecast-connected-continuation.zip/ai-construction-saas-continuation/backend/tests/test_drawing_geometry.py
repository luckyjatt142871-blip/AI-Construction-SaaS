import io
import math
import pytest
from PIL import Image
from app.drawing_geometry import screen_to_native, calibration_scale
from app.pdf_pages import render_pdf_page, raster_metadata, image_dimensions

@pytest.mark.parametrize('native,css', [((1000,700),(500,350)), ((4000,2800),(500,350)), ((2000,1000),(600,300))])
def test_native_mapping_at_different_resolutions(native, css):
    assert screen_to_native(css[0]/2,css[1]/2,(0,0,*css),*native,(0,0,*native)) == (native[0]/2,native[1]/2)

def test_zoom_pan_coordinate_mapping():
    assert screen_to_native(100,100,(0,0,500,250),4000,2000,(1000,500,2000,1000)) == (1400,900)

def test_letterboxing_is_accounted_for():
    assert screen_to_native(150,150,(0,0,400,300),1000,500,(0,0,1000,500)) == (375,250)
    with pytest.raises(ValueError): screen_to_native(150,10,(0,0,400,300),1000,500,(0,0,1000,500))

def test_calibration_stable_across_zoom():
    scale = calibration_scale((0,0),(300,400),10)
    assert math.isclose(scale,0.02)
    assert math.isclose(scale*500,10)

def test_image_dimensions_real_bytes():
    b=io.BytesIO(); Image.new('RGB',(1200,800)).save(b,format='PNG')
    assert image_dimensions(b.getvalue())['width']==1200

def test_pdf_page_is_rendered_and_dimensions_match():
    import fitz
    doc=fitz.open(); doc.new_page(width=300,height=200); raw=doc.tobytes();doc.close()
    meta=raster_metadata(raw)
    png, rendered=render_pdf_page(raw)
    assert (meta['width'],meta['height'])==(600,400)
    assert (rendered['width'],rendered['height'])==(600,400)
    assert Image.open(io.BytesIO(png)).size==(600,400)
    with pytest.raises(ValueError): raster_metadata(raw,2)
