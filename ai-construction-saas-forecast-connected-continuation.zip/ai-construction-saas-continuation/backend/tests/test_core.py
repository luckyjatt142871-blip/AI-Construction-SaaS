from app.main import ph
def test_password_hash():
    h=ph.hash('a-secure-password')
    assert 'a-secure-password' not in h
    assert ph.verify(h,'a-secure-password')
