from decimal import Decimal
from types import SimpleNamespace
from app.engines.cost_ledger import summarize_budget
from pydantic import ValidationError
import pytest

def test_budget_actual_committed():
    budget=SimpleNamespace(currency='USD',approved_amount=Decimal('1000.00'))
    entries=[SimpleNamespace(kind='actual',amount=Decimal('230.50')),SimpleNamespace(kind='committed',amount=Decimal('100.25'))]
    result=summarize_budget(budget,entries)
    assert result['remaining_after_actual_and_committed']=='669.25'
    assert result['actual_cost']=='230.50'

