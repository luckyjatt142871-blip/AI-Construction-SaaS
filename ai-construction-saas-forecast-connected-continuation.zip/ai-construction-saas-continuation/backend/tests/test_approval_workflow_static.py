from pathlib import Path

def test_approval_requires_verified_quantity_and_rate_date():
    code = (Path(__file__).parents[1] / 'app/workspace_api.py').read_text()
    assert "m.calibration_id is None" in code
    assert "not r.rate_date" in code
    assert "e.status = 'APPROVED'" in code
    assert "e.status != 'APPROVED'" in code

def test_migration_is_linked():
    code = (Path(__file__).parents[1] / 'alembic/versions/0007_estimate_approvals.py').read_text()
    assert "down_revision = '0006_calibration_integrity'" in code
