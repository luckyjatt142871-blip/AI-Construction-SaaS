from decimal import Decimal
import pytest
from app.workspace_calculations import measure, rate_total, line_amount
from app.document_validation import validate_document

def test_length_calibrated():
    assert measure('length', [[0,0],[300,400]], Decimal('0.01')) == (Decimal('5.000000'), 'm')

def test_rectangle_polygon_area():
    assert measure('area', [[0,0],[100,0],[100,200],[0,200]], Decimal('0.1')) == (Decimal('200.000000'), 'm2')

def test_count_without_scale():
    assert measure('count', [[1,2],[3,4]], None) == (Decimal('2'), 'ea')

def test_no_unverified_scale():
    with pytest.raises(ValueError): measure('length', [[0,0],[1,1]], None)

def test_reject_invalid_polygon():
    with pytest.raises(ValueError): measure('area', [[0,0],[10,10],[0,10],[10,0]], '1')

def test_rate_and_money():
    assert rate_total('1.23', '2.45', '3.01') == Decimal('6.69')
    assert line_amount('12.345', '6.69') == Decimal('82.59')

def test_reject_negative_money():
    with pytest.raises(ValueError): rate_total('-1', '2', '3')
    with pytest.raises(ValueError): line_amount('1', '-2')

def test_document_validation():
    assert len(validate_document(b'%PDF-1.7\nbody', 'application/pdf')) == 64
    with pytest.raises(ValueError): validate_document(b'<script>bad</script>', 'application/pdf')
    with pytest.raises(ValueError): validate_document(b'%PDF-1.7', 'text/html')
