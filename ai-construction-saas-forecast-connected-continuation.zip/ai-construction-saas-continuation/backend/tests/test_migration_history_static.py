"""Fast checks that migrations remain historical and form one linear chain."""
import ast
from pathlib import Path

VERSIONS = Path(__file__).resolve().parents[1] / 'alembic' / 'versions'


def _revision(path):
    values = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ('revision', 'down_revision'):
                    values[target.id] = ast.literal_eval(node.value)
    return values


def test_chain_is_linear_and_closed():
    migrations = [_revision(p) for p in VERSIONS.glob('*.py')]
    assert len(migrations) >= 7
    assert len({m['revision'] for m in migrations}) == len(migrations)
    assert sum(m['down_revision'] is None for m in migrations) == 1
    revisions = {m['revision'] for m in migrations}
    assert all(m['down_revision'] is None or m['down_revision'] in revisions for m in migrations)
    assert len({m['down_revision'] for m in migrations if m['down_revision']}) == len(migrations) - 1


def test_historical_migrations_do_not_import_live_orm():
    for name in ('0001_initial.py', '0003_workspace.py'):
        source = (VERSIONS / name).read_text()
        assert 'Base.metadata' not in source
        assert 'from app.main import Base' not in source
        assert '.create(bind=' not in source


def test_initial_schema_does_not_precreate_later_columns():
    initial = (VERSIONS / '0001_initial.py').read_text()
    for later_column in ('email_verified', 'mfa_last_step', 'calibration_id', 'approved_by'):
        assert later_column not in initial
