from decimal import Decimal
from types import SimpleNamespace as Obj
import pytest
from app.estimate_integrity import validate_rate_date, validate_line_snapshot


def fixtures():
    calibration = Obj(id=10, company_id=1, project_id=3, drawing_id=4, drawing_revision=2, page_number=5)
    measurement = Obj(id=20, company_id=1, project_id=3, drawing_id=4, drawing_revision=2, page_number=5, calibration_id=10, quantity=Decimal('4'), unit='m')
    rate = Obj(company_id=1, unit='m', currency='USD', provenance='supplier quote', rate_date='2026-10-08', material=Decimal('10'), labour=Decimal('2'), equipment=Decimal('3'))
    line = Obj(company_id=1, quantity=Decimal('4'), unit_rate=Decimal('15'), amount=Decimal('60'))
    return line, measurement, rate, calibration


def test_valid_snapshot():
    validate_line_snapshot(*fixtures(), currency='USD')

@pytest.mark.parametrize('value', ['2026-02-30', '2026-13-01', '2026-2-1', '2026-00-01'])
def test_invalid_calendar_date(value):
    with pytest.raises(ValueError): validate_rate_date(value)

@pytest.mark.parametrize('field,value', [('company_id',2),('project_id',99),('drawing_id',9),('drawing_revision',1),('page_number',6)])
def test_calibration_scope_rejected(field,value):
    line,m,r,c=fixtures(); setattr(c,field,value)
    with pytest.raises(ValueError,match='scope mismatch'):validate_line_snapshot(line,m,r,c,currency='USD')

@pytest.mark.parametrize('field,value', [('quantity',Decimal('5')),('unit_rate',Decimal('12')),('amount',Decimal('40'))])
def test_stale_line_rejected(field,value):
    line,m,r,c=fixtures();setattr(line,field,value)
    with pytest.raises(ValueError,match='stale|mismatch'):validate_line_snapshot(line,m,r,c,currency='USD')

def test_stale_rate_rejected():
    line,m,r,c=fixtures();r.material=Decimal('20')
    with pytest.raises(ValueError,match='stale'):validate_line_snapshot(line,m,r,c,currency='USD')
