from decimal import Decimal
from types import SimpleNamespace
import pytest
from app.calibration_rules import calibrated_quantity

def cal(page=1, rev=1, drawing=10, scale='0.01'):
    return SimpleNamespace(page_number=page, drawing_revision=rev, drawing_id=drawing, scale_m_per_pixel=Decimal(scale))

@pytest.mark.parametrize('page,scale,expected', [(1,'0.01','1.000000'),(2,'0.02','2.000000'),(3,'0.005','0.500000')])
def test_independent_page_scales(page,scale,expected):
    q,u=calibrated_quantity('length', [[10,10],[110,10]], calibration=cal(page=page,scale=scale), drawing_id=10,drawing_revision=1,page_number=page,width=1000,height=1000)
    assert str(q)==expected and u=='m'

@pytest.mark.parametrize('wrong', [dict(page_number=2),dict(drawing_revision=2),dict(drawing_id=11)])
def test_reject_cross_page_revision_or_drawing(wrong):
    c=cal()
    for k,v in wrong.items(): setattr(c,k,v)
    with pytest.raises(ValueError, match='different'):
        calibrated_quantity('length',[[0,0],[100,0]],calibration=c,drawing_id=10,drawing_revision=1,page_number=1,width=1000,height=1000)

def test_missing_calibration():
    with pytest.raises(ValueError, match='no calibration'):
        calibrated_quantity('length',[[0,0],[100,0]],calibration=None,drawing_id=10,drawing_revision=1,page_number=1,width=1000,height=1000)

@pytest.mark.parametrize('points', [[[0,0],[1001,0]],[[0,0],[0,501]],[[0,0],[-1,2]]])
def test_native_bounds(points):
    with pytest.raises(ValueError, match='outside page'):
        calibrated_quantity('length',points,calibration=cal(),drawing_id=10,drawing_revision=1,page_number=1,width=1000,height=500)

def test_area_independent_of_zoom_and_resolution():
    for width, scale, pts in [(1000,'0.01',[[0,0],[100,0],[100,100],[0,100]]),(2000,'0.005',[[0,0],[200,0],[200,200],[0,200]])]:
        q,u=calibrated_quantity('polygon',pts,calibration=cal(scale=scale),drawing_id=10,drawing_revision=1,page_number=1,width=width,height=width)
        assert q==Decimal('1.000000') and u=='m2'
