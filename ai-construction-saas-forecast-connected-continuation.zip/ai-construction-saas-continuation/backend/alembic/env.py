from alembic import context
from sqlalchemy import create_engine, pool
from app.main import Base, settings
config=context.config
target_metadata=Base.metadata
def run_migrations_online():
    engine=create_engine(settings.database_url,poolclass=pool.NullPool)
    with engine.connect() as connection:
        context.configure(connection=connection,target_metadata=target_metadata,compare_type=True)
        with context.begin_transaction(): context.run_migrations()
    engine.dispose()
run_migrations_online()
