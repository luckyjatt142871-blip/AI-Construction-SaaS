"""Deterministic historical workspace tables (revision 0003)."""
from alembic import op
import sqlalchemy as sa

revision = '0003'
down_revision = '0002'
branch_labels = None
depends_on = None
TABLES = ('drawings', 'measurements', 'rate_items', 'estimates', 'estimate_lines')


def tenant_cols():
    return [sa.Column('id', sa.Integer(), primary_key=True), sa.Column('company_id', sa.Integer(), sa.ForeignKey('companies.id'), nullable=False)]


def upgrade():
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if 'drawings' not in existing:
        op.create_table('drawings', *tenant_cols(),
        sa.Column('project_id', sa.Integer(), sa.ForeignKey('projects.id'), nullable=False),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('object_key', sa.String(300), nullable=False, unique=True),
        sa.Column('sha256', sa.String(64), nullable=False),
        sa.Column('size_bytes', sa.Integer(), nullable=False),
        sa.Column('media_type', sa.String(60), nullable=False),
        sa.Column('scale_m_per_pixel', sa.Numeric(20,12)))
    if 'measurements' not in existing:
        op.create_table('measurements', *tenant_cols(),
        sa.Column('project_id', sa.Integer(), sa.ForeignKey('projects.id'), nullable=False),
        sa.Column('drawing_id', sa.Integer(), sa.ForeignKey('drawings.id'), nullable=False),
        sa.Column('kind', sa.String(20), nullable=False),
        sa.Column('points_json', sa.String(6000), nullable=False),
        sa.Column('quantity', sa.Numeric(20,6), nullable=False),
        sa.Column('unit', sa.String(10), nullable=False),
        sa.Column('revision', sa.Integer(), nullable=False))
    if 'rate_items' not in existing:
        op.create_table('rate_items', *tenant_cols(),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('description', sa.String(250), nullable=False),
        sa.Column('unit', sa.String(10), nullable=False),
        sa.Column('material', sa.Numeric(20,4), nullable=False),
        sa.Column('labour', sa.Numeric(20,4), nullable=False),
        sa.Column('equipment', sa.Numeric(20,4), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False),
        sa.Column('provenance', sa.String(250), nullable=False),
        sa.UniqueConstraint('company_id','code'))
    if 'estimates' not in existing:
        op.create_table('estimates', *tenant_cols(),
        sa.Column('project_id', sa.Integer(), sa.ForeignKey('projects.id'), nullable=False),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False),
        sa.Column('status', sa.String(20), nullable=False))
    if 'estimate_lines' not in existing:
        op.create_table('estimate_lines', *tenant_cols(),
        sa.Column('estimate_id', sa.Integer(), sa.ForeignKey('estimates.id'), nullable=False),
        sa.Column('measurement_id', sa.Integer(), sa.ForeignKey('measurements.id'), nullable=False),
        sa.Column('rate_id', sa.Integer(), sa.ForeignKey('rate_items.id'), nullable=False),
        sa.Column('quantity', sa.Numeric(20,6), nullable=False),
        sa.Column('unit_rate', sa.Numeric(20,4), nullable=False),
        sa.Column('amount', sa.Numeric(20,2), nullable=False))
    for table in TABLES:
        if table not in existing:
            op.create_index(f'ix_{table}_company_id', table, ['company_id'])
    for table in ('drawings','measurements','estimates'):
        if table not in existing:
            op.create_index(f'ix_{table}_project_id', table, ['project_id'])
    if 'estimate_lines' not in existing:
        op.create_index('ix_estimate_lines_estimate_id', 'estimate_lines', ['estimate_id'])
    for table in TABLES:
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f'DROP POLICY IF EXISTS tenant_scope ON {table}')
        op.execute(f"CREATE POLICY tenant_scope ON {table} USING (company_id = NULLIF(current_setting('app.tenant_id', true),'')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true),'')::integer)")


def downgrade():
    for table in reversed(TABLES):
        op.execute(f'DROP POLICY IF EXISTS tenant_scope ON {table}')
        op.drop_table(table)
