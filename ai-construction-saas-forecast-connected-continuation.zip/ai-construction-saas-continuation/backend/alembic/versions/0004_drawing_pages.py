"""Persist source PDF page for each takeoff measurement.

Revision ID: 0004_drawing_pages
Revises: 0003_workspace
"""
from alembic import op
import sqlalchemy as sa
revision = '0004_drawing_pages'
down_revision = '0003'
branch_labels = None
depends_on = None

def upgrade():
    if 'page_number' not in {c['name'] for c in sa.inspect(op.get_bind()).get_columns('measurements')}:
        op.add_column('measurements', sa.Column('page_number', sa.Integer(), nullable=False, server_default='1'))
    if 'ck_measurements_page_positive' not in {c['name'] for c in sa.inspect(op.get_bind()).get_check_constraints('measurements')}:
        op.create_check_constraint('ck_measurements_page_positive', 'measurements', 'page_number >= 1 AND page_number <= 300')

def downgrade():
    op.drop_constraint('ck_measurements_page_positive', 'measurements', type_='check')
    op.drop_column('measurements', 'page_number')
