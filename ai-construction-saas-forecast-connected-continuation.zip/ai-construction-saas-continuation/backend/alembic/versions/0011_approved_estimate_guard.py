"""Prevent database-level edits to approved estimate headers and line snapshots.

Additive migration: never mutates approved customer data. Existing drafts remain editable.
"""
from alembic import op

revision = '0011_approved_estimate_guard'
down_revision = '0010_project_issues'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""CREATE FUNCTION guard_approved_estimate_header() RETURNS trigger
    LANGUAGE plpgsql AS $$
    BEGIN
      IF OLD.status = 'APPROVED' THEN
        RAISE EXCEPTION 'approved estimate is immutable';
      END IF;
      IF TG_OP = 'UPDATE' AND NEW.status = 'APPROVED' AND
         (NEW.approved_by IS NULL OR NEW.approved_at IS NULL) THEN
        RAISE EXCEPTION 'approval requires approver and timestamp';
      END IF;
      RETURN NEW;
    END $$""")
    op.execute("""CREATE TRIGGER approved_estimate_header_guard
      BEFORE UPDATE OR DELETE ON estimates FOR EACH ROW
      EXECUTE FUNCTION guard_approved_estimate_header()""")
    op.execute("""CREATE FUNCTION guard_approved_estimate_lines() RETURNS trigger
    LANGUAGE plpgsql AS $$
    DECLARE parent_status text;
    BEGIN
      IF TG_OP IN ('UPDATE', 'DELETE') THEN
        SELECT status INTO parent_status FROM estimates WHERE id = OLD.estimate_id;
        IF parent_status = 'APPROVED' THEN
          RAISE EXCEPTION 'approved estimate lines are immutable';
        END IF;
      END IF;
      IF TG_OP IN ('INSERT', 'UPDATE') THEN
        SELECT status INTO parent_status FROM estimates WHERE id = NEW.estimate_id;
        IF parent_status IS NULL THEN
          RAISE EXCEPTION 'estimate does not exist';
        END IF;
        IF parent_status = 'APPROVED' THEN
          RAISE EXCEPTION 'cannot add or move lines to approved estimate';
        END IF;
      END IF;
      RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
    END $$""")
    op.execute("""CREATE TRIGGER approved_estimate_lines_guard
      BEFORE INSERT OR UPDATE OR DELETE ON estimate_lines FOR EACH ROW
      EXECUTE FUNCTION guard_approved_estimate_lines()""")


def downgrade():
    op.execute('DROP TRIGGER IF EXISTS approved_estimate_lines_guard ON estimate_lines')
    op.execute('DROP FUNCTION IF EXISTS guard_approved_estimate_lines()')
    op.execute('DROP TRIGGER IF EXISTS approved_estimate_header_guard ON estimates')
    op.execute('DROP FUNCTION IF EXISTS guard_approved_estimate_header()')
