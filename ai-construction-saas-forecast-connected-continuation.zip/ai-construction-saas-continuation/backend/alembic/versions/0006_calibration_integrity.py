"""Guard persisted measurement source against cross-page and cross-tenant substitution."""
from alembic import op
import sqlalchemy as sa
revision = '0006_calibration_integrity'
down_revision = '0005_page_calibrations'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('measurements', sa.Column('drawing_revision', sa.Integer(), nullable=True))
    op.execute("""
    CREATE FUNCTION enforce_measurement_calibration() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF NEW.calibration_id IS NULL THEN
        IF TG_OP = 'INSERT' THEN
          RAISE EXCEPTION 'New measurements require a page calibration';
        END IF;
        IF NEW.drawing_id IS DISTINCT FROM OLD.drawing_id OR
           NEW.page_number IS DISTINCT FROM OLD.page_number OR
           NEW.quantity IS DISTINCT FROM OLD.quantity OR
           NEW.points_json IS DISTINCT FROM OLD.points_json THEN
          RAISE EXCEPTION 'Unverified legacy measurements cannot be remeasured';
        END IF;
        RETURN NEW;
      END IF;
      IF NEW.drawing_revision IS NULL OR NOT EXISTS (
        SELECT 1 FROM drawing_calibrations c
        WHERE c.id = NEW.calibration_id AND c.company_id = NEW.company_id
          AND c.project_id = NEW.project_id AND c.drawing_id = NEW.drawing_id
          AND c.drawing_revision = NEW.drawing_revision
          AND c.page_number = NEW.page_number
      ) THEN
        RAISE EXCEPTION 'Calibration does not match tenant, drawing, revision and page';
      END IF;
      RETURN NEW;
    END; $$;
    """)
    op.execute("""CREATE TRIGGER measurement_calibration_guard BEFORE INSERT OR UPDATE ON measurements
      FOR EACH ROW EXECUTE FUNCTION enforce_measurement_calibration()""")
    op.execute("""CREATE FUNCTION prevent_calibration_mutation() RETURNS trigger
      LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Calibration records are immutable'; END; $$""")
    op.execute("""CREATE TRIGGER calibration_immutable_guard BEFORE UPDATE OR DELETE ON drawing_calibrations
      FOR EACH ROW EXECUTE FUNCTION prevent_calibration_mutation()""")

def downgrade():
    op.execute('DROP TRIGGER calibration_immutable_guard ON drawing_calibrations')
    op.execute('DROP FUNCTION prevent_calibration_mutation()')
    op.execute('DROP TRIGGER measurement_calibration_guard ON measurements')
    op.execute('DROP FUNCTION enforce_measurement_calibration()')
    op.drop_column('measurements', 'drawing_revision')
