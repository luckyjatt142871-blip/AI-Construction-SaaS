"""Versioned project cost-to-complete assumptions and RLS."""
from alembic import op
import sqlalchemy as sa
revision='0013_project_cost_forecasts'
down_revision='0012_project_rfis'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('project_cost_forecasts',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('remaining_cost',sa.Numeric(18,2),nullable=False),
        sa.Column('currency',sa.String(3),nullable=False),
        sa.Column('source_reference',sa.String(240),nullable=False),
        sa.Column('recorded_by',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('as_of',sa.Date(),nullable=False),
        sa.CheckConstraint('remaining_cost >= 0',name='ck_forecast_remaining_nonnegative'))
    op.create_index('ix_project_cost_forecasts_company_id','project_cost_forecasts',['company_id'])
    op.create_index('ix_project_cost_forecasts_project_id','project_cost_forecasts',['project_id'])
    op.execute('ALTER TABLE project_cost_forecasts ENABLE ROW LEVEL SECURITY')
    op.execute('ALTER TABLE project_cost_forecasts FORCE ROW LEVEL SECURITY')
    op.execute("CREATE POLICY project_cost_forecasts_tenant ON project_cost_forecasts USING (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer)")
    op.execute("""CREATE FUNCTION enforce_forecast_scope() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM projects WHERE id=NEW.project_id AND company_id=NEW.company_id) THEN
        RAISE EXCEPTION 'forecast project scope mismatch';
      END IF;
      IF NOT EXISTS (SELECT 1 FROM project_budgets WHERE project_id=NEW.project_id AND company_id=NEW.company_id AND currency=NEW.currency) THEN
        RAISE EXCEPTION 'forecast budget currency mismatch';
      END IF;
      RETURN NEW;
    END $$""")
    op.execute('CREATE TRIGGER project_cost_forecasts_scope BEFORE INSERT OR UPDATE ON project_cost_forecasts FOR EACH ROW EXECUTE FUNCTION enforce_forecast_scope()')

def downgrade():
    op.drop_table('project_cost_forecasts')
    op.execute('DROP FUNCTION enforce_forecast_scope()')
