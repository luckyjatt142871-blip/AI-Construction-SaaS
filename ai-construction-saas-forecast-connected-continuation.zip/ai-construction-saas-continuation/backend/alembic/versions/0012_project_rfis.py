"""Add project RFIs with forced tenant RLS and project consistency trigger."""
from alembic import op
import sqlalchemy as sa
revision = '0012_project_rfis'
down_revision = '0011_approved_estimate_guard'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('project_rfis',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('company_id', sa.Integer(), sa.ForeignKey('companies.id'), nullable=False),
        sa.Column('project_id', sa.Integer(), sa.ForeignKey('projects.id'), nullable=False),
        sa.Column('reference', sa.String(50), nullable=False),
        sa.Column('subject', sa.String(200), nullable=False),
        sa.Column('question', sa.Text(), nullable=False),
        sa.Column('answer', sa.Text(), nullable=True),
        sa.Column('status', sa.String(12), nullable=False, server_default='open'),
        sa.Column('created_by', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('answered_by', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('answered_at', sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint('company_id','project_id','reference',name='uq_project_rfi_reference'),
        sa.CheckConstraint("status IN ('open','answered','closed')",name='ck_project_rfi_status'))
    op.create_index('ix_project_rfis_company_id','project_rfis',['company_id'])
    op.create_index('ix_project_rfis_project_id','project_rfis',['project_id'])
    op.execute('ALTER TABLE project_rfis ENABLE ROW LEVEL SECURITY')
    op.execute('ALTER TABLE project_rfis FORCE ROW LEVEL SECURITY')
    op.execute("CREATE POLICY project_rfis_tenant ON project_rfis USING (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer)")
    op.execute("""CREATE FUNCTION enforce_rfi_scope() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM projects WHERE id=NEW.project_id AND company_id=NEW.company_id) THEN
        RAISE EXCEPTION 'rfi project scope mismatch';
      END IF;
      RETURN NEW;
    END $$""")
    op.execute('CREATE TRIGGER project_rfis_scope BEFORE INSERT OR UPDATE ON project_rfis FOR EACH ROW EXECUTE FUNCTION enforce_rfi_scope()')

def downgrade():
    op.drop_table('project_rfis')
    op.execute('DROP FUNCTION enforce_rfi_scope()')
