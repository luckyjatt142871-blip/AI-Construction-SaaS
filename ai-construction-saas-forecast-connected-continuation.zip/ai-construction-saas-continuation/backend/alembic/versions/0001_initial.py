"""Deterministic historical baseline. Never import live ORM metadata here.

Revision ID: 0001
"""
from alembic import op
import sqlalchemy as sa

revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('users',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('email', sa.String(320), nullable=False),
        sa.Column('password_hash', sa.String(255), nullable=False),
        sa.Column('platform_role', sa.String(40)),
        sa.Column('mfa_secret', sa.String(512)),
        sa.Column('mfa_enabled', sa.Boolean(), nullable=False),
        sa.Column('failed_logins', sa.Integer(), nullable=False),
        sa.Column('locked_until', sa.DateTime(timezone=True)))
    op.create_index('ix_users_email', 'users', ['email'], unique=True)
    op.create_table('companies', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('name', sa.String(200), nullable=False))
    op.create_table('memberships',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('company_id', sa.Integer(), sa.ForeignKey('companies.id'), nullable=False),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('role', sa.String(40), nullable=False),
        sa.UniqueConstraint('company_id', 'user_id'))
    op.create_table('sessions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('token_hash', sa.String(64), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('csrf_hash', sa.String(64), nullable=False))
    op.create_index('ix_sessions_token_hash', 'sessions', ['token_hash'], unique=True)
    op.create_table('projects',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('company_id', sa.Integer(), sa.ForeignKey('companies.id'), nullable=False),
        sa.Column('name', sa.String(200), nullable=False))
    op.create_index('ix_projects_company_id', 'projects', ['company_id'])
    op.create_table('audit_logs',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('company_id', sa.Integer(), sa.ForeignKey('companies.id')),
        sa.Column('actor_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('action', sa.String(100), nullable=False),
        sa.Column('metadata_json', sa.String(2000), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))
    op.create_index('ix_audit_logs_company_id', 'audit_logs', ['company_id'])
    op.create_table('security_events',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('actor_id', sa.Integer(), sa.ForeignKey('users.id')),
        sa.Column('event', sa.String(100), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))
    op.create_table('email_verifications',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('token_hash', sa.String(64), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False))
    # Preserve historical policy names and tenant context for upgrade compatibility.
    op.execute("""CREATE FUNCTION my_company_ids(p_user_id integer) RETURNS TABLE(company_id integer)
        LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
        SELECT m.company_id FROM memberships m WHERE m.user_id = p_user_id
        AND p_user_id::text = current_setting('app.user_id',true) $$""")
    for table in ('memberships', 'projects', 'audit_logs'):
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f"CREATE POLICY tenant_scope ON {table} USING (company_id = NULLIF(current_setting('app.tenant_id', true),'')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true),'')::integer)")


def downgrade():
    for table in ('audit_logs', 'projects', 'memberships'):
        op.execute(f'DROP POLICY IF EXISTS tenant_scope ON {table}')
    op.execute('DROP FUNCTION IF EXISTS my_company_ids(integer)')
    for table in ('email_verifications', 'security_events', 'audit_logs', 'projects', 'sessions', 'memberships', 'companies', 'users'):
        op.drop_table(table)
