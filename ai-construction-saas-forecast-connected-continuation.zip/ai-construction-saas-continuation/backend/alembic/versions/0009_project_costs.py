"""Tenant-owned 5D budgets and project cost entries."""
from alembic import op
import sqlalchemy as sa
revision='0009_project_costs'
down_revision='0008_project_scheduling'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('project_budgets',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('currency',sa.String(3),nullable=False),sa.Column('approved_amount',sa.Numeric(18,2),nullable=False),sa.UniqueConstraint('company_id','project_id',name='uq_project_budget_scope'),sa.CheckConstraint('approved_amount >= 0',name='ck_budget_nonnegative'))
    op.create_table('project_cost_entries',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('kind',sa.String(12),nullable=False),sa.Column('description',sa.String(240),nullable=False),sa.Column('amount',sa.Numeric(18,2),nullable=False),sa.Column('currency',sa.String(3),nullable=False),sa.Column('occurred_on',sa.Date(),nullable=False),sa.Column('source_reference',sa.String(240),nullable=False),sa.CheckConstraint('amount >= 0',name='ck_cost_nonnegative'),sa.CheckConstraint("kind IN ('actual','committed')",name='ck_cost_kind'))
    for table in ('project_budgets','project_cost_entries'):
        op.create_index('ix_'+table+'_company_id',table,['company_id'])
        op.create_index('ix_'+table+'_project_id',table,['project_id'])
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f"CREATE POLICY {table}_tenant ON {table} USING (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer)")
    op.execute("""CREATE FUNCTION enforce_project_cost_scope() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM projects WHERE id=NEW.project_id AND company_id=NEW.company_id) THEN
        RAISE EXCEPTION 'cost project scope mismatch';
      END IF;
      RETURN NEW;
    END $$""")
    for table in ('project_budgets','project_cost_entries'):
        op.execute(f'CREATE TRIGGER {table}_scope BEFORE INSERT OR UPDATE ON {table} FOR EACH ROW EXECUTE FUNCTION enforce_project_cost_scope()')

def downgrade():
    for table in ('project_cost_entries','project_budgets'):
        op.drop_table(table)
    op.execute('DROP FUNCTION enforce_project_cost_scope()')
