"""Add immutable approval metadata and rate provenance date."""
from alembic import op
import sqlalchemy as sa
revision = '0007_estimate_approvals'
down_revision = '0006_calibration_integrity'
branch_labels = None
depends_on = None

def upgrade():
    rate_columns = {c['name'] for c in sa.inspect(op.get_bind()).get_columns('rate_items')}
    estimate_columns = {c['name'] for c in sa.inspect(op.get_bind()).get_columns('estimates')}
    if 'rate_date' not in rate_columns:
        op.add_column('rate_items', sa.Column('rate_date', sa.String(10), nullable=True))
    if 'revision' not in estimate_columns:
        op.add_column('estimates', sa.Column('revision', sa.Integer(), nullable=False, server_default='1'))
    if 'approved_by' not in estimate_columns:
        op.add_column('estimates', sa.Column('approved_by', sa.Integer(), sa.ForeignKey('users.id'), nullable=True))
    if 'approved_at' not in estimate_columns:
        op.add_column('estimates', sa.Column('approved_at', sa.String(40), nullable=True))

def downgrade():
    op.drop_column('estimates', 'approved_at')
    op.drop_column('estimates', 'approved_by')
    op.drop_column('estimates', 'revision')
    op.drop_column('rate_items', 'rate_date')
