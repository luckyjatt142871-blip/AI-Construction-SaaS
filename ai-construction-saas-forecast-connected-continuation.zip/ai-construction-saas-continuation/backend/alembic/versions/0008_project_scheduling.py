"""Project-linked activities and dependency edges with tenant RLS."""
from alembic import op
import sqlalchemy as sa
revision='0008_project_scheduling'
down_revision='0007_estimate_approvals'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('schedule_activities',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('code',sa.String(60),nullable=False),sa.Column('name',sa.String(200),nullable=False),sa.Column('duration_days',sa.Integer(),nullable=False),sa.Column('progress_percent',sa.Integer(),nullable=False,server_default='0'),sa.UniqueConstraint('company_id','project_id','code',name='uq_schedule_activity_code'),sa.CheckConstraint('duration_days >= 0',name='ck_schedule_duration'),sa.CheckConstraint('progress_percent >= 0 AND progress_percent <= 100',name='ck_schedule_progress'))
    op.create_table('schedule_dependencies',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('predecessor_id',sa.Integer(),sa.ForeignKey('schedule_activities.id',ondelete='CASCADE'),nullable=False),sa.Column('successor_id',sa.Integer(),sa.ForeignKey('schedule_activities.id',ondelete='CASCADE'),nullable=False),sa.UniqueConstraint('company_id','project_id','predecessor_id','successor_id',name='uq_schedule_dependency'),sa.CheckConstraint('predecessor_id <> successor_id',name='ck_schedule_no_self'))
    for table in ('schedule_activities','schedule_dependencies'):
        op.create_index('ix_'+table+'_company_id',table,['company_id'])
        op.create_index('ix_'+table+'_project_id',table,['project_id'])
        op.execute(f'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE {table} FORCE ROW LEVEL SECURITY')
        op.execute(f"CREATE POLICY {table}_tenant ON {table} USING (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer)")
    op.execute("""CREATE FUNCTION enforce_schedule_scope() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF TG_TABLE_NAME = 'schedule_activities' THEN
        IF NOT EXISTS (SELECT 1 FROM projects WHERE id = NEW.project_id AND company_id = NEW.company_id) THEN RAISE EXCEPTION 'schedule project scope mismatch'; END IF;
      ELSE
        IF NOT EXISTS (SELECT 1 FROM schedule_activities WHERE id = NEW.predecessor_id AND company_id = NEW.company_id AND project_id = NEW.project_id)
          OR NOT EXISTS (SELECT 1 FROM schedule_activities WHERE id = NEW.successor_id AND company_id = NEW.company_id AND project_id = NEW.project_id) THEN RAISE EXCEPTION 'schedule dependency scope mismatch'; END IF;
      END IF;
      RETURN NEW;
    END $$""")
    for table in ('schedule_activities','schedule_dependencies'):
        op.execute(f'CREATE TRIGGER {table}_scope BEFORE INSERT OR UPDATE ON {table} FOR EACH ROW EXECUTE FUNCTION enforce_schedule_scope()')

def downgrade():
    for table in ('schedule_dependencies','schedule_activities'):
        op.drop_table(table)
    op.execute('DROP FUNCTION enforce_schedule_scope()')
