"""Project issue register with forced tenant RLS and project scope checks."""
from alembic import op
import sqlalchemy as sa
revision='0010_project_issues'
down_revision='0009_project_costs'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('project_issues',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('reference',sa.String(40),nullable=False),
        sa.Column('title',sa.String(200),nullable=False),
        sa.Column('description',sa.String(2000),nullable=False),
        sa.Column('status',sa.String(20),nullable=False,server_default='open'),
        sa.Column('priority',sa.String(12),nullable=False,server_default='normal'),
        sa.UniqueConstraint('company_id','project_id','reference',name='uq_issue_reference'),
        sa.CheckConstraint("status IN ('open','in_progress','resolved')",name='ck_issue_status'),
        sa.CheckConstraint("priority IN ('low','normal','high','critical')",name='ck_issue_priority'))
    op.create_index('ix_project_issues_company_id','project_issues',['company_id'])
    op.create_index('ix_project_issues_project_id','project_issues',['project_id'])
    op.execute('ALTER TABLE project_issues ENABLE ROW LEVEL SECURITY')
    op.execute('ALTER TABLE project_issues FORCE ROW LEVEL SECURITY')
    op.execute("CREATE POLICY project_issues_tenant ON project_issues USING (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true), '')::integer)")
    op.execute("""CREATE FUNCTION enforce_issue_scope() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM projects WHERE id=NEW.project_id AND company_id=NEW.company_id) THEN
        RAISE EXCEPTION 'issue project scope mismatch';
      END IF;
      RETURN NEW;
    END $$""")
    op.execute('CREATE TRIGGER project_issues_scope BEFORE INSERT OR UPDATE ON project_issues FOR EACH ROW EXECUTE FUNCTION enforce_issue_scope()')

def downgrade():
    op.drop_table('project_issues')
    op.execute('DROP FUNCTION enforce_issue_scope()')
