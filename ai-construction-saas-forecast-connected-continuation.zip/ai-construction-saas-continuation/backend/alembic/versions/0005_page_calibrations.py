"""Immutable per-page, per-revision calibration history and measurement provenance."""
from alembic import op
import sqlalchemy as sa
revision = '0005_page_calibrations'
down_revision = '0004_drawing_pages'
branch_labels = None
depends_on = None

def upgrade():
    if 'revision' not in {c['name'] for c in sa.inspect(op.get_bind()).get_columns('drawings')}:
        op.add_column('drawings', sa.Column('revision', sa.Integer(), nullable=False, server_default='1'))
    if 'drawing_calibrations' not in sa.inspect(op.get_bind()).get_table_names():
        op.create_table('drawing_calibrations',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('company_id', sa.Integer(), sa.ForeignKey('companies.id'), nullable=False),
        sa.Column('project_id', sa.Integer(), sa.ForeignKey('projects.id'), nullable=False),
        sa.Column('drawing_id', sa.Integer(), sa.ForeignKey('drawings.id'), nullable=False),
        sa.Column('drawing_revision', sa.Integer(), nullable=False),
        sa.Column('page_number', sa.Integer(), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False),
        sa.Column('scale_m_per_pixel', sa.Numeric(24,15), nullable=False),
        sa.Column('known_meters', sa.Numeric(24,9), nullable=False),
        sa.Column('pixel_distance', sa.Numeric(24,9), nullable=False),
        sa.UniqueConstraint('drawing_id','drawing_revision','page_number','version', name='uq_drawing_calibration_version'),
        sa.CheckConstraint('page_number BETWEEN 1 AND 300', name='ck_calibration_page'),
        sa.CheckConstraint('drawing_revision >= 1 AND version >= 1', name='ck_calibration_versions'),
        sa.CheckConstraint('scale_m_per_pixel > 0 AND known_meters > 0 AND pixel_distance > 0', name='ck_calibration_positive'))
    existing_indexes = {i['name'] for i in sa.inspect(op.get_bind()).get_indexes('drawing_calibrations')}
    if 'ix_drawing_calibrations_company_id' not in existing_indexes:
        op.create_index('ix_drawing_calibrations_company_id', 'drawing_calibrations', ['company_id'])
    if 'ix_drawing_calibrations_drawing_id' not in existing_indexes:
        op.create_index('ix_drawing_calibrations_drawing_id', 'drawing_calibrations', ['drawing_id'])
    if 'calibration_id' not in {c['name'] for c in sa.inspect(op.get_bind()).get_columns('measurements')}:
        op.add_column('measurements', sa.Column('calibration_id', sa.Integer(), sa.ForeignKey('drawing_calibrations.id'), nullable=True))
    # Old measurements remain unverified: never silently assign them a page calibration.
    op.execute('ALTER TABLE drawing_calibrations ENABLE ROW LEVEL SECURITY')
    op.execute('ALTER TABLE drawing_calibrations FORCE ROW LEVEL SECURITY')
    op.execute('DROP POLICY IF EXISTS tenant_scope ON drawing_calibrations')
    op.execute("CREATE POLICY tenant_scope ON drawing_calibrations USING (company_id = NULLIF(current_setting('app.tenant_id', true),'')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.tenant_id', true),'')::integer)")

def downgrade():
    op.drop_column('measurements', 'calibration_id')
    op.execute('DROP POLICY tenant_scope ON drawing_calibrations')
    op.drop_table('drawing_calibrations')
    op.drop_column('drawings', 'revision')
