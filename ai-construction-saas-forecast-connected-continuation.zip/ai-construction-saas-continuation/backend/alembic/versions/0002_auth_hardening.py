"""Authentication hardening schema"""
from alembic import op
import sqlalchemy as sa
revision='0002'
down_revision='0001'
branch_labels=None
depends_on=None
def upgrade():
    # Earlier 0001 used metadata.create_all, so existing fresh databases may
    # already have these objects. Keep upgrade idempotent for that baseline.
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {c['name'] for c in inspector.get_columns('users')}
    if 'email_verified' not in columns:
        op.add_column('users',sa.Column('email_verified',sa.Boolean(),server_default=sa.false(),nullable=False))
    if 'mfa_last_step' not in columns:
        op.add_column('users',sa.Column('mfa_last_step',sa.Integer(),server_default='-1',nullable=False))
    tables = set(inspector.get_table_names())
    if 'password_resets' not in tables:
        op.create_table('password_resets',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('token_hash',sa.String(64),unique=True,nullable=False),sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False))
    if 'mfa_recovery' not in tables:
        op.create_table('mfa_recovery',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('code_hash',sa.String(64),unique=True,nullable=False))
        op.create_index('ix_mfa_recovery_user_id','mfa_recovery',['user_id'])
def downgrade():
    op.drop_index('ix_mfa_recovery_user_id',table_name='mfa_recovery')
    op.drop_table('mfa_recovery')
    op.drop_table('password_resets')
    op.drop_column('users','mfa_last_step')
    op.drop_column('users','email_verified')
