"""Project issue register; tenant and project scoped."""
from sqlalchemy import ForeignKey, String, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.main import Base

class ProjectIssue(Base):
    __tablename__ = 'project_issues'
    __table_args__ = (
        CheckConstraint("status IN ('open','in_progress','resolved')", name='ck_issue_status'),
        CheckConstraint("priority IN ('low','normal','high','critical')", name='ck_issue_priority'),
        UniqueConstraint('company_id','project_id','reference',name='uq_issue_reference'),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'),nullable=False,index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'),nullable=False,index=True)
    reference: Mapped[str] = mapped_column(String(40),nullable=False)
    title: Mapped[str] = mapped_column(String(200),nullable=False)
    description: Mapped[str] = mapped_column(String(2000),nullable=False)
    status: Mapped[str] = mapped_column(String(20),nullable=False,default='open')
    priority: Mapped[str] = mapped_column(String(12),nullable=False,default='normal')
