"""Tenant-owned scheduling records."""
from sqlalchemy import ForeignKey, String, UniqueConstraint, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.main import Base

class ScheduleActivity(Base):
    __tablename__ = 'schedule_activities'
    __table_args__ = (UniqueConstraint('company_id','project_id','code',name='uq_schedule_activity_code'), CheckConstraint('duration_days >= 0',name='ck_schedule_duration'), CheckConstraint('progress_percent >= 0 AND progress_percent <= 100',name='ck_schedule_progress'))
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'),nullable=False,index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'),nullable=False,index=True)
    code: Mapped[str] = mapped_column(String(60),nullable=False)
    name: Mapped[str] = mapped_column(String(200),nullable=False)
    duration_days: Mapped[int] = mapped_column(nullable=False)
    progress_percent: Mapped[int] = mapped_column(default=0,nullable=False)

class ScheduleDependency(Base):
    __tablename__ = 'schedule_dependencies'
    __table_args__ = (UniqueConstraint('company_id','project_id','predecessor_id','successor_id',name='uq_schedule_dependency'),CheckConstraint('predecessor_id <> successor_id',name='ck_schedule_no_self'))
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'),nullable=False,index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'),nullable=False,index=True)
    predecessor_id: Mapped[int] = mapped_column(ForeignKey('schedule_activities.id',ondelete='CASCADE'),nullable=False)
    successor_id: Mapped[int] = mapped_column(ForeignKey('schedule_activities.id',ondelete='CASCADE'),nullable=False)
