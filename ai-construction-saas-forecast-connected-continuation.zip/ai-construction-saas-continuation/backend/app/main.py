import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Annotated
from fastapi import FastAPI, Depends, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from sqlalchemy import text
import hmac, json, logging, os, time, uuid
import pyotp
from cryptography.fernet import Fernet
from pydantic import BaseModel, EmailStr, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import create_engine, String, ForeignKey, DateTime, UniqueConstraint, select, event, delete
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, Session, sessionmaker
from app.authorization import Permission, authorized
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from sqlalchemy.exc import IntegrityError

class Settings(BaseSettings):
    database_url: str = 'postgresql+psycopg://invalid:invalid@localhost:5432/estimator'
    cookie_secure: bool = True
    session_days: int = 7
    app_env: str = 'development'
    redis_url: str = 'redis://localhost:6379/0'
    allowed_origins: str = 'http://localhost:3000'
    smtp_host: str = ''
    smtp_port: int = 587
    smtp_username: str = ''
    smtp_password: str = ''
    email_from: str = ''
    platform_bootstrap_email: str = ''
    mfa_encryption_key: str = ''
    rate_limit_per_minute: int = 60
    auth_rate_limit_per_minute: int = 10
    max_failed_logins: int = 5
    storage_bucket: str = ''
    storage_endpoint: str = ''
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')
settings = Settings()
if settings.app_env == 'production':
    if not settings.cookie_secure or not settings.storage_bucket or not settings.database_url.startswith('postgresql+') or not settings.redis_url.startswith('rediss://') or not settings.mfa_encryption_key or not settings.allowed_origins.startswith('https://'):
        raise RuntimeError('Unsafe production configuration')
engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(engine)
ph = PasswordHasher()
DUMMY_PASSWORD_HASH = ph.hash('invalid-dummy-credential')
def record_failed_login(session,user):
    user.failed_logins += 1
    if user.failed_logins >= settings.max_failed_logins:
        user.locked_until = datetime.now(timezone.utc)+timedelta(minutes=15)
        user.failed_logins=0
    session.add(SecurityEvent(actor_id=user.id,event='auth.failed_login'))
    session.commit()

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__='users'
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(320),unique=True,index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    platform_role: Mapped[str | None] = mapped_column(String(40),nullable=True)
    mfa_secret: Mapped[str | None] = mapped_column(String(512),nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(default=False)
    email_verified: Mapped[bool] = mapped_column(default=False)
    mfa_last_step: Mapped[int] = mapped_column(default=-1)
    failed_logins: Mapped[int] = mapped_column(default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True),nullable=True)
class Company(Base):
    __tablename__='companies'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
class Membership(Base):
    __tablename__='memberships'
    __table_args__=(UniqueConstraint('company_id','user_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'))
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    role: Mapped[str] = mapped_column(String(40))
class SessionToken(Base):
    __tablename__='sessions'
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    token_hash: Mapped[str] = mapped_column(String(64),unique=True,index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    csrf_hash: Mapped[str] = mapped_column(String(64))
class Project(Base):
    __tablename__='projects'
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'),index=True)
    name: Mapped[str] = mapped_column(String(200))
class AuditLog(Base):
    __tablename__='audit_logs'
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int | None] = mapped_column(ForeignKey('companies.id'),nullable=True,index=True)
    actor_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    action: Mapped[str] = mapped_column(String(100))
    metadata_json: Mapped[str] = mapped_column(String(2000),default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

class SecurityEvent(Base):
    __tablename__ = 'security_events'
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey('users.id'),nullable=True)
    event: Mapped[str] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

class PasswordReset(Base):
    __tablename__ = "password_resets"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class MFARecovery(Base):
    __tablename__ = "mfa_recovery"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    code_hash: Mapped[str] = mapped_column(String(64), unique=True)

class EmailVerification(Base):
    __tablename__ = 'email_verifications'
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    token_hash: Mapped[str] = mapped_column(String(64),unique=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

from app.workspace_models import Drawing, Measurement, RateItem, Estimate, EstimateLine

app=FastAPI(title='AI Construction Estimating API',version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=settings.allowed_origins.split(','),allow_credentials=True,allow_methods=['GET','POST','PATCH','DELETE'],allow_headers=['Content-Type','X-CSRF-Token'])

@app.middleware('http')
async def security_middleware(request: Request, call_next):
    from redis.asyncio import Redis
    request_id = str(uuid.uuid4())
    if request.url.path.startswith('/api/'):
        client_ip = request.client.host if request.client else 'unknown'
        # Only use trusted reverse proxy forwarding at the infrastructure layer.
        try:
            redis = Redis.from_url(settings.redis_url, socket_connect_timeout=1)
            try:
                bucket = int(time.time() // 60)
                auth = request.url.path.startswith('/api/auth/')
                key = f'rate:{"auth" if auth else "api"}:{client_ip}:{bucket}'
                count = await redis.incr(key)
                if count == 1: await redis.expire(key, 65)
                if count > (settings.auth_rate_limit_per_minute if auth else settings.rate_limit_per_minute):
                    return __import__('fastapi').responses.JSONResponse({'detail':'Rate limit exceeded'},status_code=429)
            finally: await redis.aclose()
        except Exception:
            # Fail closed on auth routes if limiter is unavailable.
            if request.url.path.startswith('/api/'):
                return __import__('fastapi').responses.JSONResponse({'detail':'Authentication temporarily unavailable'},status_code=503)
        if request.method in ('POST','PATCH','PUT','DELETE') and request.cookies.get('session') and request.url.path != '/api/auth/login':
            supplied = request.headers.get('X-CSRF-Token','')
            cookie = request.cookies.get('csrf','')
            if not supplied or not hmac.compare_digest(supplied,cookie):
                return __import__('fastapi').responses.JSONResponse({'detail':'CSRF validation failed'},status_code=403)
    response = await call_next(request)
    response.headers['X-Request-ID'] = request_id
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    if settings.cookie_secure: response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    response.headers['Content-Security-Policy']="default-src 'none'; frame-ancestors 'none'"
    return response

class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12,max_length=128)
class CompanyInput(BaseModel): name: str = Field(min_length=2,max_length=200)
class ProjectInput(BaseModel): name: str = Field(min_length=2,max_length=200)
def db():
    with SessionLocal() as session: yield session
DB=Annotated[Session,Depends(db)]
def current_user(request:Request,session:DB)->User:
    token=request.cookies.get('session')
    if not token: raise HTTPException(401,'Authentication required')
    digest=hashlib.sha256(token.encode()).hexdigest()
    record=session.scalar(select(SessionToken).where(SessionToken.token_hash==digest,SessionToken.expires_at>datetime.now(timezone.utc)))
    if record is None: raise HTTPException(401,'Session expired')
    csrf=request.cookies.get('csrf','')
    if not csrf or not hmac.compare_digest(record.csrf_hash,hashlib.sha256(csrf.encode()).hexdigest()): raise HTTPException(401,'Invalid session')
    user=session.get(User,record.user_id)
    if user is None: raise HTTPException(401,'Authentication required')
    return user
UserDep=Annotated[User,Depends(current_user)]
def member(session:Session,user:User,company_id:int,roles:tuple[str,...]|None=None):
    # Membership authorization is checked before setting the tenant context.
    # The DB function verifies membership using the session's authenticated user ID.
    if session.bind.dialect.name == 'postgresql':
        session.execute(text("SELECT set_config('app.user_id', :uid, true)"), {'uid':str(user.id)})
        permitted=session.scalar(text('SELECT EXISTS(SELECT 1 FROM my_company_ids(:uid) WHERE company_id=:cid)').bindparams(uid=user.id,cid=company_id))
        if not permitted: raise HTTPException(404,'Resource not found')
        session.execute(text("SELECT set_config('app.tenant_id', :tenant, true)"),{'tenant':str(company_id)})
    m=session.scalar(select(Membership).where(Membership.company_id==company_id,Membership.user_id==user.id))
    if m is None: raise HTTPException(404,'Resource not found')
    if roles and m.role not in roles: raise HTTPException(403,'Insufficient permissions')
    return m
@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/api/auth/signup',status_code=201)
def signup(data:Credentials,session:DB):
    email=data.email.lower()
    if session.scalar(select(User).where(User.email==email)): raise HTTPException(409,'Account exists')
    user=User(email=email,password_hash=ph.hash(data.password));session.add(user);session.commit()
    return {'id':user.id,'email':user.email}
@app.post('/api/auth/login')
def login(data:Credentials,response:Response,session:DB):
    user=session.scalar(select(User).where(User.email==data.email.lower()))
    if user and user.locked_until and user.locked_until > datetime.now(timezone.utc):
        raise HTTPException(423,'Account locked')
    try:
        ph.verify(user.password_hash if user else DUMMY_PASSWORD_HASH,data.password)
    except (VerifyMismatchError,VerificationError):
        if user: record_failed_login(session,user)
        raise HTTPException(401,'Invalid credentials')
    if user is None: raise HTTPException(401,'Invalid credentials')
    # Do not clear lockout state until all login factors succeed.
    if user.locked_until and user.locked_until > datetime.now(timezone.utc): raise HTTPException(423,'Account locked')
    if not user.email_verified: raise HTTPException(403,'Email verification required')
    if user.mfa_enabled: raise HTTPException(401,'MFA required: use /api/auth/login/mfa')
    user.failed_logins=0; user.locked_until=None
    token=secrets.token_urlsafe(48)
    csrf=secrets.token_urlsafe(32)
    session.add(SessionToken(user_id=user.id,token_hash=hashlib.sha256(token.encode()).hexdigest(),csrf_hash=hashlib.sha256(csrf.encode()).hexdigest(),expires_at=datetime.now(timezone.utc)+timedelta(days=settings.session_days)))
    session.commit()
    response.set_cookie('session',token,httponly=True,secure=settings.cookie_secure,samesite='strict',max_age=settings.session_days*86400,path='/')
    response.set_cookie('csrf',csrf,httponly=False,secure=settings.cookie_secure,samesite='strict',max_age=settings.session_days*86400,path='/')
    return {'id':user.id,'email':user.email}
@app.post('/api/auth/logout')
def logout(request:Request,response:Response,user:UserDep,session:DB):
    token=request.cookies.get('session');session.execute(__import__('sqlalchemy').delete(SessionToken).where(SessionToken.token_hash==hashlib.sha256(token.encode()).hexdigest()));session.commit();response.delete_cookie('session',path='/');response.delete_cookie('csrf',path='/');return {'ok':True}
@app.get('/api/auth/me')
def me(user:UserDep):return {'id':user.id,'email':user.email}
@app.post('/api/companies',status_code=201)
def create_company(data:CompanyInput,user:UserDep,session:DB):
    company=Company(name=data.name);session.add(company);session.flush()
    if session.bind.dialect.name == 'postgresql': session.execute(text("SELECT set_config('app.tenant_id', :tenant, true)"),{'tenant':str(company.id)})
    session.add(Membership(company_id=company.id,user_id=user.id,role='COMPANY_OWNER'))
    session.add(AuditLog(company_id=company.id,actor_id=user.id,action='company.created'))
    session.commit();return {'id':company.id,'name':company.name}
@app.get('/api/companies')
def companies(user:UserDep,session:DB):
    # Membership listing is deliberately performed using a dedicated SECURITY DEFINER function in PostgreSQL.
    if session.bind.dialect.name == 'postgresql':
        session.execute(text("SELECT set_config('app.user_id', :uid, true)"), {'uid':str(user.id)})
        rows=session.scalars(select(Company).where(Company.id.in_(text('SELECT company_id FROM my_company_ids(:uid)').bindparams(uid=user.id)))).all()
    else:
        rows=session.execute(select(Company).join(Membership,Company.id==Membership.company_id).where(Membership.user_id==user.id)).scalars().all()
    return [{'id':c.id,'name':c.name} for c in rows]
@app.post('/api/companies/{company_id}/projects',status_code=201)
def create_project(company_id:int,data:ProjectInput,user:UserDep,session:DB):
    m=member(session,user,company_id)
    if not authorized(m.role,Permission.PROJECT_CREATE,member_company_id=m.company_id,resource_company_id=company_id): raise HTTPException(403,'Insufficient permissions')
    project=Project(company_id=company_id,name=data.name);session.add(project);session.flush()
    session.add(AuditLog(company_id=company_id,actor_id=user.id,action='project.created'))
    session.commit();return {'id':project.id,'name':project.name}
@app.get('/api/companies/{company_id}/projects')
def projects(company_id:int,user:UserDep,session:DB):
    member(session,user,company_id)
    return [{'id':p.id,'name':p.name} for p in session.scalars(select(Project).where(Project.company_id==company_id))]
@app.get('/api/companies/{company_id}/projects/{project_id}')
def project(company_id:int,project_id:int,user:UserDep,session:DB):
    member(session,user,company_id)
    p=session.scalar(select(Project).where(Project.id==project_id,Project.company_id==company_id))
    if p is None:raise HTTPException(404,'Resource not found')
    return {'id':p.id,'name':p.name}

PLATFORM_ROLES = {'PLATFORM_OWNER','PLATFORM_ADMIN','SUPPORT_ADMIN','REVIEWER'}
def platform_guard(user:User, allowed:tuple[str,...]):
    if user.platform_role not in allowed: raise HTTPException(403,'Platform permission denied')

@app.get('/api/admin/status')
def admin_status(user:UserDep):
    platform_guard(user,('PLATFORM_OWNER','PLATFORM_ADMIN','SUPPORT_ADMIN','REVIEWER'))
    return {'role':user.platform_role,'scope':'platform'}

@app.get('/api/admin/companies')
def admin_companies(user:UserDep,session:DB):
    platform_guard(user,('PLATFORM_OWNER','PLATFORM_ADMIN'))
    # Platform-wide reads require a separately privileged connection; no implicit RLS bypass.
    raise HTTPException(501,'Platform-wide listing requires dedicated audited admin database role')

@app.get('/api/companies/{company_id}/audit')
def company_audit(company_id:int,user:UserDep,session:DB):
    m=member(session,user,company_id)
    if not authorized(m.role,Permission.AUDIT_READ,member_company_id=m.company_id,resource_company_id=company_id): raise HTTPException(403,'Insufficient permissions')
    return [{'action':x.action,'at':x.created_at} for x in session.scalars(select(AuditLog).where(AuditLog.company_id==company_id).order_by(AuditLog.id.desc()).limit(100))]

class MFAInput(Credentials):
    otp: str = Field(min_length=6,max_length=8)

@app.post('/api/auth/mfa/setup')
def mfa_setup(user:UserDep,session:DB):
    if not settings.mfa_encryption_key: raise HTTPException(503,'MFA encryption key not configured')
    if user.mfa_enabled: raise HTTPException(409,'MFA already enabled')
    secret=pyotp.random_base32()
    user.mfa_secret=Fernet(settings.mfa_encryption_key.encode()).encrypt(secret.encode()).decode()
    session.add(AuditLog(actor_id=user.id,action='mfa.setup'))
    session.commit()
    return {'provisioning_uri':pyotp.TOTP(secret).provisioning_uri(name=user.email,issuer_name='Construction Estimating')}

class OTPInput(BaseModel):
    otp: str = Field(min_length=6,max_length=8)

@app.post('/api/auth/mfa/enable')
def mfa_enable(data:OTPInput,user:UserDep,session:DB):
    if not user.mfa_secret or not settings.mfa_encryption_key: raise HTTPException(400,'MFA setup required')
    secret=Fernet(settings.mfa_encryption_key.encode()).decrypt(user.mfa_secret.encode()).decode()
    if not pyotp.TOTP(secret).verify(data.otp,valid_window=1): raise HTTPException(400,'Invalid code')
    user.mfa_enabled=True
    user.mfa_last_step=next(i for i in range(int(time.time()//30)-1,int(time.time()//30)+2) if pyotp.TOTP(secret).at(i*30)==data.otp)
    session.add(AuditLog(actor_id=user.id,action='mfa.enabled'))
    session.commit()
    return {'enabled':True}

@app.post('/api/auth/login/mfa')
def login_mfa(data:MFAInput,response:Response,session:DB):
    user=session.scalar(select(User).where(User.email==data.email.lower()).with_for_update())
    if not user or not user.mfa_enabled or not user.mfa_secret: raise HTTPException(401,'Invalid credentials')
    if user.locked_until and user.locked_until > datetime.now(timezone.utc): raise HTTPException(423,'Account locked')
    try: ph.verify(user.password_hash,data.password)
    except (VerifyMismatchError,VerificationError):
        record_failed_login(session,user)
        raise HTTPException(401,'Invalid credentials')
    if user.locked_until and user.locked_until > datetime.now(timezone.utc): raise HTTPException(423,'Account locked')
    if not user.email_verified: raise HTTPException(403,'Email verification required')
    secret=Fernet(settings.mfa_encryption_key.encode()).decrypt(user.mfa_secret.encode()).decode()
    totp=pyotp.TOTP(secret)
    step=int(time.time()//totp.interval)
    accepted=next((i for i in (step-1,step,step+1) if i>user.mfa_last_step and hmac.compare_digest(totp.at(i*totp.interval),data.otp)),None)
    if accepted is None:
        record_failed_login(session,user)
        raise HTTPException(401,'Invalid credentials')
    user.mfa_last_step=accepted
    user.failed_logins=0; user.locked_until=None
    token=secrets.token_urlsafe(48); csrf=secrets.token_urlsafe(32)
    session.add(SessionToken(user_id=user.id,token_hash=hashlib.sha256(token.encode()).hexdigest(),csrf_hash=hashlib.sha256(csrf.encode()).hexdigest(),expires_at=datetime.now(timezone.utc)+timedelta(days=settings.session_days)))
    session.commit()
    response.set_cookie('session',token,httponly=True,secure=settings.cookie_secure,samesite='strict',max_age=settings.session_days*86400)
    response.set_cookie('csrf',csrf,httponly=False,secure=settings.cookie_secure,samesite='strict',max_age=settings.session_days*86400)
    return {'id':user.id,'email':user.email}

class TokenInput(BaseModel):
    token: str = Field(min_length=32,max_length=256)
class ResetInput(TokenInput):
    password: str = Field(min_length=12,max_length=128)
class EmailInput(BaseModel):
    email: EmailStr

def deliver_token(to:str,kind:str,token:str):
    from app.email_adapter import SMTPEmailAdapter
    SMTPEmailAdapter().send(to, f"Construction Estimating {kind}", f"Your {kind} token (expires in 30 minutes): {token}")

@app.post('/api/auth/verification/request')
def request_verification(data:EmailInput,session:DB):
    user=session.scalar(select(User).where(User.email==data.email.lower()))
    if user and not user.email_verified:
        token=secrets.token_urlsafe(48)
        session.add(EmailVerification(user_id=user.id,token_hash=hashlib.sha256(token.encode()).hexdigest(),expires_at=datetime.now(timezone.utc)+timedelta(minutes=30)))
        session.commit()
        deliver_token(user.email,'email verification',token)
    return {'message':'If eligible, a verification email has been sent'}

@app.post('/api/auth/verification/confirm')
def confirm_verification(data:TokenInput,session:DB):
    digest=hashlib.sha256(data.token.encode()).hexdigest()
    record=session.scalar(select(EmailVerification).where(EmailVerification.token_hash==digest,EmailVerification.expires_at>datetime.now(timezone.utc)))
    if record is None: raise HTTPException(400,'Invalid or expired token')
    user=session.get(User,record.user_id);user.email_verified=True
    session.execute(delete(EmailVerification).where(EmailVerification.user_id==user.id,EmailVerification.id!=record.id))
    session.delete(record);session.commit()
    return {'verified':True}

@app.post('/api/auth/password/forgot')
def forgot_password(data:EmailInput,session:DB):
    user=session.scalar(select(User).where(User.email==data.email.lower()))
    if user and user.email_verified:
        token=secrets.token_urlsafe(48)
        session.add(PasswordReset(user_id=user.id,token_hash=hashlib.sha256(token.encode()).hexdigest(),expires_at=datetime.now(timezone.utc)+timedelta(minutes=30)))
        session.commit()
        deliver_token(user.email,'password reset',token)
    return {'message':'If eligible, a password reset email has been sent'}

@app.post('/api/auth/password/reset')
def reset_password(data:ResetInput,session:DB):
    digest=hashlib.sha256(data.token.encode()).hexdigest()
    record=session.scalar(select(PasswordReset).where(PasswordReset.token_hash==digest,PasswordReset.expires_at>datetime.now(timezone.utc)))
    if record is None: raise HTTPException(400,'Invalid or expired token')
    user=session.get(User,record.user_id)
    user.password_hash=ph.hash(data.password)
    user.failed_logins=0; user.locked_until=None
    session.execute(delete(PasswordReset).where(PasswordReset.user_id==user.id,PasswordReset.id!=record.id))
    session.execute(__import__('sqlalchemy').delete(SessionToken).where(SessionToken.user_id==user.id))
    session.delete(record);session.commit()
    return {'reset':True}

class RecoveryRotationInput(BaseModel):
    password: str = Field(min_length=12,max_length=128)
    otp: str = Field(min_length=6,max_length=8)

@app.post('/api/auth/mfa/recovery/generate')
def generate_recovery(data:RecoveryRotationInput,user:UserDep,session:DB):
    # Step-up authentication is required before rotating all recovery codes.
    locked=session.scalar(select(User).where(User.id==user.id).with_for_update())
    if not locked or not locked.mfa_enabled or not locked.mfa_secret:
        raise HTTPException(400,'MFA must be enabled')
    if locked.locked_until and locked.locked_until > datetime.now(timezone.utc):
        raise HTTPException(423,'Account locked')
    try:
        ph.verify(locked.password_hash,data.password)
    except (VerifyMismatchError,VerificationError):
        record_failed_login(session,locked)
        raise HTTPException(401,'Invalid credentials')
    if not settings.mfa_encryption_key:
        raise HTTPException(503,'MFA encryption key not configured')
    secret=Fernet(settings.mfa_encryption_key.encode()).decrypt(locked.mfa_secret.encode()).decode()
    totp=pyotp.TOTP(secret)
    step=int(time.time()//totp.interval)
    accepted=next((i for i in (step-1,step,step+1)
                   if i>locked.mfa_last_step and hmac.compare_digest(totp.at(i*totp.interval),data.otp)),None)
    if accepted is None:
        record_failed_login(session,locked)
        raise HTTPException(401,'Invalid credentials')
    locked.mfa_last_step=accepted
    codes=[secrets.token_hex(16) for _ in range(8)]
    session.execute(delete(MFARecovery).where(MFARecovery.user_id==locked.id))
    for code in codes:
        session.add(MFARecovery(user_id=locked.id,code_hash=hashlib.sha256(code.encode()).hexdigest()))
    session.add(SecurityEvent(actor_id=locked.id,event='mfa.recovery_rotated'))
    session.commit()
    return {'codes':codes,'warning':'Store these one-time codes securely; they will not be shown again'}

class MFARecoveryLogin(Credentials):
    recovery_code: str = Field(min_length=32,max_length=64)

@app.post('/api/auth/login/recovery')
def login_recovery(data:MFARecoveryLogin,response:Response,session:DB):
    user=session.scalar(select(User).where(User.email==data.email.lower()).with_for_update())
    if not user or not user.mfa_enabled or not user.email_verified: raise HTTPException(401,'Invalid credentials')
    if user.locked_until and user.locked_until > datetime.now(timezone.utc): raise HTTPException(423,'Account locked')
    try: ph.verify(user.password_hash,data.password)
    except (VerifyMismatchError,VerificationError):
        record_failed_login(session,user)
        raise HTTPException(401,'Invalid credentials')
    digest=hashlib.sha256(data.recovery_code.encode()).hexdigest()
    code=session.scalar(select(MFARecovery).where(MFARecovery.user_id==user.id,MFARecovery.code_hash==digest).with_for_update())
    if not code:
        record_failed_login(session,user)
        raise HTTPException(401,'Invalid credentials')
    session.delete(code)
    user.failed_logins=0;user.locked_until=None
    token=secrets.token_urlsafe(48);csrf=secrets.token_urlsafe(32)
    session.add(SessionToken(user_id=user.id,token_hash=hashlib.sha256(token.encode()).hexdigest(),csrf_hash=hashlib.sha256(csrf.encode()).hexdigest(),expires_at=datetime.now(timezone.utc)+timedelta(days=settings.session_days)))
    session.add(SecurityEvent(actor_id=user.id,event='mfa.recovery_used'))
    session.commit()
    response.set_cookie('session',token,httponly=True,secure=settings.cookie_secure,samesite='strict',max_age=settings.session_days*86400,path='/')
    response.set_cookie('csrf',csrf,httponly=False,secure=settings.cookie_secure,samesite='strict',max_age=settings.session_days*86400,path='/')
    return {'id':user.id,'email':user.email}

# Workspace routes are registered after the existing authentication dependencies.
from app.workspace_api import register_workspace
register_workspace(app, db, current_user, member, Project, AuditLog, settings)

from app.schedule_api import register_schedule
register_schedule(app, db, current_user, member, Project, AuditLog)

from app.cost_api import register_cost_api
register_cost_api(app, db, current_user, member, Project)

from app.issue_api import register_issue_api
register_issue_api(app, db, current_user, member, Project)

from app.rfi_api import register_rfi_api
register_rfi_api(app, db, current_user, member, Project, AuditLog)

from app.project_overview_api import register_project_overview
register_project_overview(app, db, current_user, member, Project)
