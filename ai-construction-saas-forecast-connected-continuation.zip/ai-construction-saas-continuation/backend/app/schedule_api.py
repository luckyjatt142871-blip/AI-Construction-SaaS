"""Authenticated project schedule API backed by the existing CPM engine."""
from typing import Annotated
from fastapi import Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, delete
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.authorization import authorized, Permission
from app.schedule_models import ScheduleActivity, ScheduleDependency
from app.engines.scheduling import Activity, calculate_critical_path

class ActivityInput(BaseModel):
    code: str = Field(min_length=1,max_length=60)
    name: str = Field(min_length=2,max_length=200)
    duration_days: int = Field(ge=0,le=36500)
    progress_percent: int = Field(default=0,ge=0,le=100)

class DependencyInput(BaseModel):
    predecessor_id: int
    successor_id: int

def register_schedule(app,db,current_user,member,Project,AuditLog):
    DB=Annotated[Session,Depends(db)]
    UserDep=Annotated[object,Depends(current_user)]
    def scope(session,user,cid,pid,write=False):
        m=member(session,user,cid)
        permission=Permission.PROJECT_CREATE if write else Permission.PROJECT_READ
        if not authorized(m.role,permission,member_company_id=m.company_id,resource_company_id=cid):raise HTTPException(403,'Forbidden')
        if not session.scalar(select(Project.id).where(Project.id==pid,Project.company_id==cid)):raise HTTPException(404,'Project not found')
    def get_activity(session,cid,pid,aid):
        item=session.scalar(select(ScheduleActivity).where(ScheduleActivity.id==aid,ScheduleActivity.company_id==cid,ScheduleActivity.project_id==pid))
        if item is None:raise HTTPException(404,'Activity not found')
        return item
    def serialize(a):return {'id':a.id,'code':a.code,'name':a.name,'duration_days':a.duration_days,'progress_percent':a.progress_percent,'milestone':a.duration_days==0}
    prefix='/api/companies/{company_id}/projects/{project_id}/schedule'
    @app.get(prefix)
    def read_schedule(company_id:int,project_id:int,user:UserDep,session:DB):
        scope(session,user,company_id,project_id)
        activities=list(session.scalars(select(ScheduleActivity).where(ScheduleActivity.company_id==company_id,ScheduleActivity.project_id==project_id).order_by(ScheduleActivity.id)))
        dependencies=list(session.scalars(select(ScheduleDependency).where(ScheduleDependency.company_id==company_id,ScheduleDependency.project_id==project_id)))
        predecessors={a.id:[] for a in activities}
        for dep in dependencies:predecessors[dep.successor_id].append(str(dep.predecessor_id))
        try:finish,results=calculate_critical_path([Activity(str(a.id),a.duration_days,tuple(predecessors[a.id])) for a in activities])
        except ValueError as exc:raise HTTPException(409,str(exc)) from exc
        return {'duration_days':finish,'activities':[dict(serialize(a), **{k:v for k,v in vars(next(r for r in results if r.id==str(a.id))).items() if k != 'id'}) for a in activities], 'dependencies':[{'id':d.id,'predecessor_id':d.predecessor_id,'successor_id':d.successor_id} for d in dependencies]}
    @app.post(prefix+'/activities',status_code=201)
    def create_activity(company_id:int,project_id:int,data:ActivityInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        a=ScheduleActivity(company_id=company_id,project_id=project_id,**data.model_dump())
        session.add(a)
        try:session.commit()
        except IntegrityError as exc:session.rollback();raise HTTPException(409,'Duplicate activity code') from exc
        return serialize(a)
    @app.patch(prefix+'/activities/{activity_id}')
    def edit_activity(company_id:int,project_id:int,activity_id:int,data:ActivityInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        a=get_activity(session,company_id,project_id,activity_id)
        for key,value in data.model_dump().items():setattr(a,key,value)
        try:session.commit()
        except IntegrityError as exc:session.rollback();raise HTTPException(409,'Duplicate activity code') from exc
        return serialize(a)
    @app.delete(prefix+'/activities/{activity_id}',status_code=204)
    def remove_activity(company_id:int,project_id:int,activity_id:int,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        a=get_activity(session,company_id,project_id,activity_id)
        session.delete(a);session.commit()
    @app.post(prefix+'/dependencies',status_code=201)
    def add_dependency(company_id:int,project_id:int,data:DependencyInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        if data.predecessor_id==data.successor_id:raise HTTPException(422,'Self dependency')
        for aid in (data.predecessor_id,data.successor_id):get_activity(session,company_id,project_id,aid)
        deps=list(session.scalars(select(ScheduleDependency).where(ScheduleDependency.company_id==company_id,ScheduleDependency.project_id==project_id)))
        activities=list(session.scalars(select(ScheduleActivity).where(ScheduleActivity.company_id==company_id,ScheduleActivity.project_id==project_id)))
        preds={a.id:[] for a in activities}
        for d in deps:preds[d.successor_id].append(str(d.predecessor_id))
        preds[data.successor_id].append(str(data.predecessor_id))
        try:calculate_critical_path([Activity(str(a.id),a.duration_days,tuple(preds[a.id])) for a in activities])
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
        dep=ScheduleDependency(company_id=company_id,project_id=project_id,**data.model_dump())
        session.add(dep)
        try:session.commit()
        except IntegrityError as exc:session.rollback();raise HTTPException(409,'Duplicate dependency') from exc
        return {'id':dep.id,**data.model_dump()}
    @app.delete(prefix+'/dependencies/{dependency_id}',status_code=204)
    def remove_dependency(company_id:int,project_id:int,dependency_id:int,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        dep=session.scalar(select(ScheduleDependency).where(ScheduleDependency.id==dependency_id,ScheduleDependency.company_id==company_id,ScheduleDependency.project_id==project_id))
        if dep is None:raise HTTPException(404,'Dependency not found')
        session.delete(dep);session.commit()
