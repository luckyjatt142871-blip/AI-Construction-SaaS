"""Authorized issue register API with scoped updates."""
from typing import Annotated, Literal
from fastapi import Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.authorization import Permission, authorized
from app.issue_models import ProjectIssue

class IssueInput(BaseModel):
    reference: str = Field(min_length=1,max_length=40)
    title: str = Field(min_length=2,max_length=200)
    description: str = Field(default='',max_length=2000)
    priority: Literal['low','normal','high','critical'] = 'normal'

class IssueUpdate(BaseModel):
    title: str | None = Field(default=None,min_length=2,max_length=200)
    description: str | None = Field(default=None,max_length=2000)
    status: Literal['open','in_progress','resolved'] | None = None
    priority: Literal['low','normal','high','critical'] | None = None

def serialize(issue):
    return {key:getattr(issue,key) for key in ('id','company_id','project_id','reference','title','description','status','priority')}

def register_issue_api(app,db,current_user,member,Project):
    DB=Annotated[Session,Depends(db)]
    UserDep=Annotated[object,Depends(current_user)]
    prefix='/api/companies/{company_id}/projects/{project_id}/issues'
    def scope(session,user,cid,pid,write=False):
        m=member(session,user,cid)
        permission=Permission.PROJECT_CREATE if write else Permission.PROJECT_READ
        if not authorized(m.role,permission,member_company_id=m.company_id,resource_company_id=cid):
            raise HTTPException(403,'Forbidden')
        if session.scalar(select(Project.id).where(Project.id==pid,Project.company_id==cid)) is None:
            raise HTTPException(404,'Project not found')
    @app.get(prefix)
    def list_issues(company_id:int,project_id:int,user:UserDep,session:DB):
        scope(session,user,company_id,project_id)
        return [serialize(x) for x in session.scalars(select(ProjectIssue).where(ProjectIssue.company_id==company_id,ProjectIssue.project_id==project_id).order_by(ProjectIssue.id))]
    @app.post(prefix,status_code=201)
    def create_issue(company_id:int,project_id:int,data:IssueInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        issue=ProjectIssue(company_id=company_id,project_id=project_id,**data.model_dump())
        session.add(issue)
        try: session.commit()
        except IntegrityError as exc:
            session.rollback();raise HTTPException(409,'Duplicate issue reference') from exc
        session.refresh(issue)
        return serialize(issue)
    @app.patch(prefix+'/{issue_id}')
    def update_issue(company_id:int,project_id:int,issue_id:int,data:IssueUpdate,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        issue=session.scalar(select(ProjectIssue).where(ProjectIssue.id==issue_id,ProjectIssue.company_id==company_id,ProjectIssue.project_id==project_id))
        if issue is None:raise HTTPException(404,'Issue not found')
        for key,value in data.model_dump(exclude_unset=True).items():
            if value is None:raise HTTPException(422,'Null values not allowed')
            setattr(issue,key,value)
        session.commit()
        return serialize(issue)
