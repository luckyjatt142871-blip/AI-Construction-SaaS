"""Deterministic approved-BOQ exports; no third-party rate data."""
from decimal import Decimal
from io import BytesIO

def _total(rows):
    return sum((Decimal(row['amount']) for row in rows), Decimal('0.00'))

def export_excel(name, currency, rows):
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook(); ws = wb.active; ws.title = 'BOQ'
    ws.append([name, currency]); ws.append(['Item', 'Measurement ID', 'Rate ID', 'Quantity', 'Unit rate', 'Amount'])
    for row in rows:
        ws.append([row['item'], row['measurement_id'], row['rate_id'], float(Decimal(row['quantity'])), float(Decimal(row['unit_rate'])), float(Decimal(row['amount']))])
    ws.append(['TOTAL', None, None, None, None, float(_total(rows))]); ws['A2'].font = Font(bold=True)
    for column in 'ABCDEF': ws.column_dimensions[column].width = 21
    stream = BytesIO(); wb.save(stream); return stream.getvalue()

def export_pdf(name, currency, rows):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from xml.sax.saxutils import escape
    stream = BytesIO(); doc = SimpleDocTemplate(stream, pagesize=A4)
    data = [['#', 'Measurement', 'Rate', 'Qty', 'Unit rate', 'Amount']]
    for row in rows:
        data.append([str(row[k]) for k in ('item','measurement_id','rate_id','quantity','unit_rate','amount')])
    data.append(['TOTAL','','','','',str(_total(rows))])
    table = Table(data, repeatRows=1, hAlign='LEFT'); table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('GRID',(0,0),(-1,-1),0.25,colors.grey),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
    doc.build([Paragraph(escape(name), getSampleStyleSheet()['Title']), Paragraph(escape(currency), getSampleStyleSheet()['Normal']),Spacer(1,12),table])
    return stream.getvalue()
