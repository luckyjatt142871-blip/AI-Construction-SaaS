"""Deterministic pre-approval validation of saved estimate line snapshots."""
from datetime import date
from decimal import Decimal


def validate_rate_date(value: str) -> str:
    """Reject impossible or non-ISO calendar dates without changing stored format."""
    if not isinstance(value, str) or len(value) != 10:
        raise ValueError('Rate date must be YYYY-MM-DD')
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError('Rate date must be a real YYYY-MM-DD date') from exc
    if parsed.isoformat() != value:
        raise ValueError('Rate date must be YYYY-MM-DD')
    return value


def validate_line_snapshot(line, measurement, rate, calibration, *, currency: str) -> None:
    """Check tenant-scoped provenance and immutable numeric snapshots before approval."""
    if measurement is None or rate is None or calibration is None:
        raise ValueError('Missing measurement, rate or calibration')
    if not rate.provenance or not rate.rate_date:
        raise ValueError('Rate provenance and effective date required')
    validate_rate_date(rate.rate_date)
    if (measurement.company_id != line.company_id or
        calibration.company_id != line.company_id or
        rate.company_id != line.company_id or
        calibration.project_id != measurement.project_id or
        calibration.drawing_id != measurement.drawing_id or
        calibration.drawing_revision != measurement.drawing_revision or
        calibration.page_number != measurement.page_number or
        measurement.calibration_id != calibration.id):
        raise ValueError('Quantity calibration scope mismatch')
    if measurement.unit != rate.unit or rate.currency != currency:
        raise ValueError('Rate unit or currency mismatch')
    from app.workspace_calculations import rate_total, line_amount
    if Decimal(line.quantity) != Decimal(measurement.quantity):
        raise ValueError('Estimate quantity is stale; create a new revision')
    if Decimal(line.unit_rate) != rate_total(rate.material, rate.labour, rate.equipment):
        raise ValueError('Estimate rate is stale; create a new revision')
    if Decimal(line.amount) != line_amount(line.quantity, line.unit_rate):
        raise ValueError('Estimate line amount mismatch')
