"""Persistent, tenant-owned project workspace records."""
from decimal import Decimal
from sqlalchemy import ForeignKey, String, Numeric, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.main import Base

class Drawing(Base):
    __tablename__ = 'drawings'
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'), index=True)
    name: Mapped[str] = mapped_column(String(200))
    object_key: Mapped[str] = mapped_column(String(300), unique=True)
    sha256: Mapped[str] = mapped_column(String(64))
    size_bytes: Mapped[int]
    media_type: Mapped[str] = mapped_column(String(60))
    revision: Mapped[int] = mapped_column(default=1, nullable=False)
    scale_m_per_pixel: Mapped[Decimal | None] = mapped_column(Numeric(20, 12), nullable=True)

class Measurement(Base):
    __tablename__ = 'measurements'
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'), index=True)
    drawing_id: Mapped[int] = mapped_column(ForeignKey('drawings.id'))
    page_number: Mapped[int] = mapped_column(default=1)
    calibration_id: Mapped[int | None] = mapped_column(ForeignKey('drawing_calibrations.id'), nullable=True)
    drawing_revision: Mapped[int | None] = mapped_column(nullable=True)
    kind: Mapped[str] = mapped_column(String(20))
    points_json: Mapped[str] = mapped_column(String(6000))
    quantity: Mapped[Decimal] = mapped_column(Numeric(20, 6))
    unit: Mapped[str] = mapped_column(String(10))
    revision: Mapped[int] = mapped_column(default=1)

class RateItem(Base):
    __tablename__ = 'rate_items'
    __table_args__ = (UniqueConstraint('company_id', 'code'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), index=True)
    code: Mapped[str] = mapped_column(String(50))
    description: Mapped[str] = mapped_column(String(250))
    unit: Mapped[str] = mapped_column(String(10))
    material: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    labour: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    equipment: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    currency: Mapped[str] = mapped_column(String(3))
    provenance: Mapped[str] = mapped_column(String(250))
    rate_date: Mapped[str | None] = mapped_column(String(10), nullable=True)

class Estimate(Base):
    __tablename__ = 'estimates'
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'), index=True)
    name: Mapped[str] = mapped_column(String(200))
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    revision: Mapped[int] = mapped_column(default=1, nullable=False)
    approved_by: Mapped[int | None] = mapped_column(ForeignKey('users.id'), nullable=True)
    approved_at: Mapped[str | None] = mapped_column(String(40), nullable=True)

class EstimateLine(Base):
    __tablename__ = 'estimate_lines'
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), index=True)
    estimate_id: Mapped[int] = mapped_column(ForeignKey('estimates.id'), index=True)
    measurement_id: Mapped[int] = mapped_column(ForeignKey('measurements.id'))
    rate_id: Mapped[int] = mapped_column(ForeignKey('rate_items.id'))
    quantity: Mapped[Decimal] = mapped_column(Numeric(20, 6))
    unit_rate: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 2))

class DrawingCalibration(Base):
    __tablename__ = 'drawing_calibrations'
    __table_args__ = (UniqueConstraint('drawing_id', 'drawing_revision', 'page_number', 'version', name='uq_drawing_calibration_version'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), index=True, nullable=False)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'), nullable=False)
    drawing_id: Mapped[int] = mapped_column(ForeignKey('drawings.id'), index=True, nullable=False)
    drawing_revision: Mapped[int] = mapped_column(nullable=False)
    page_number: Mapped[int] = mapped_column(nullable=False)
    version: Mapped[int] = mapped_column(nullable=False)
    scale_m_per_pixel: Mapped[Decimal] = mapped_column(Numeric(24, 15), nullable=False)
    known_meters: Mapped[Decimal] = mapped_column(Numeric(24, 9), nullable=False)
    pixel_distance: Mapped[Decimal] = mapped_column(Numeric(24, 9), nullable=False)
