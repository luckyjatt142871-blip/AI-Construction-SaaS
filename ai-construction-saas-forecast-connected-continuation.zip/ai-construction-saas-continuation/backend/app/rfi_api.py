"""Project-scoped RFI lifecycle; responses are auditable and cannot be silently overwritten."""
from datetime import datetime, timezone
from typing import Annotated
from fastapi import Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.authorization import Permission, authorized
from app.rfi_models import ProjectRFI

class RFIInput(BaseModel):
    reference: str = Field(min_length=1, max_length=50)
    subject: str = Field(min_length=2, max_length=200)
    question: str = Field(min_length=5, max_length=10000)

class RFIAnswer(BaseModel):
    answer: str = Field(min_length=2, max_length=10000)

def serialize(r):
    return {key: getattr(r, key) for key in ('id','company_id','project_id','reference','subject','question','answer','status','created_by','answered_by','created_at','answered_at')}

def register_rfi_api(app, db, current_user, member, Project, AuditLog):
    DB = Annotated[Session, Depends(db)]
    UserDep = Annotated[object, Depends(current_user)]
    prefix = '/api/companies/{company_id}/projects/{project_id}/rfis'
    def scope(session, user, cid, pid, write=False):
        m = member(session, user, cid)
        permission = Permission.PROJECT_CREATE if write else Permission.PROJECT_READ
        if not authorized(m.role, permission, member_company_id=m.company_id, resource_company_id=cid):
            raise HTTPException(403, 'Forbidden')
        if session.scalar(select(Project.id).where(Project.id == pid, Project.company_id == cid)) is None:
            raise HTTPException(404, 'Project not found')
    @app.get(prefix)
    def list_rfis(company_id: int, project_id: int, user: UserDep, session: DB):
        scope(session, user, company_id, project_id)
        return [serialize(r) for r in session.scalars(select(ProjectRFI).where(ProjectRFI.company_id == company_id, ProjectRFI.project_id == project_id).order_by(ProjectRFI.id.desc()))]
    @app.post(prefix, status_code=201)
    def create_rfi(company_id: int, project_id: int, data: RFIInput, user: UserDep, session: DB):
        scope(session, user, company_id, project_id, True)
        r = ProjectRFI(company_id=company_id, project_id=project_id, created_by=user.id, **data.model_dump())
        session.add(r)
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='rfi.created'))
        try: session.commit()
        except IntegrityError as exc:
            session.rollback()
            raise HTTPException(409, 'RFI reference already exists') from exc
        session.refresh(r)
        return serialize(r)
    @app.post(prefix + '/{rfi_id}/answer')
    def answer_rfi(company_id: int, project_id: int, rfi_id: int, data: RFIAnswer, user: UserDep, session: DB):
        scope(session, user, company_id, project_id, True)
        r = session.scalar(select(ProjectRFI).where(ProjectRFI.id == rfi_id, ProjectRFI.company_id == company_id, ProjectRFI.project_id == project_id).with_for_update())
        if r is None: raise HTTPException(404, 'RFI not found')
        if r.status != 'open': raise HTTPException(409, 'RFI is already answered or closed')
        r.answer, r.status, r.answered_by, r.answered_at = data.answer, 'answered', user.id, datetime.now(timezone.utc)
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='rfi.answered'))
        session.commit()
        return serialize(r)
    @app.post(prefix + '/{rfi_id}/close')
    def close_rfi(company_id: int, project_id: int, rfi_id: int, user: UserDep, session: DB):
        scope(session, user, company_id, project_id, True)
        r = session.scalar(select(ProjectRFI).where(ProjectRFI.id == rfi_id, ProjectRFI.company_id == company_id, ProjectRFI.project_id == project_id).with_for_update())
        if r is None: raise HTTPException(404, 'RFI not found')
        if r.status != 'answered': raise HTTPException(409, 'Only answered RFIs can be closed')
        r.status = 'closed'
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='rfi.closed'))
        session.commit()
        return serialize(r)
