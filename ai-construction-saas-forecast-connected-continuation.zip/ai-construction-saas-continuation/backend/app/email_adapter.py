"""SMTP TLS production adapter; intentionally no silent fake delivery."""
import smtplib
from email.message import EmailMessage
from app.main import settings
class SMTPEmailAdapter:
    def send(self,to:str,subject:str,body:str):
        if not all((settings.smtp_host,settings.smtp_username,settings.smtp_password,settings.email_from)):
            raise RuntimeError('SMTP is not configured')
        msg=EmailMessage(); msg['From']=settings.email_from; msg['To']=to; msg['Subject']=subject; msg.set_content(body)
        with smtplib.SMTP(settings.smtp_host,settings.smtp_port,timeout=20) as client:
            client.starttls(); client.login(settings.smtp_username,settings.smtp_password); client.send_message(msg)
