"""Authorized 5D budget and cost-entry API, no guessed currency conversions."""
from datetime import date
from decimal import Decimal
from typing import Annotated,Literal
from fastapi import Depends,HTTPException
from pydantic import BaseModel,Field,field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.authorization import authorized,Permission
from app.cost_models import ProjectBudget,ProjectCostEntry,ProjectCostForecast
from app.engines.cost_ledger import summarize_budget,forecast_completion

class BudgetInput(BaseModel):
    currency:str=Field(pattern=r'^[A-Z]{3}$')
    approved_amount:Decimal=Field(ge=0,max_digits=18,decimal_places=2)

class CostInput(BaseModel):
    kind:Literal['actual','committed']
    description:str=Field(min_length=2,max_length=240)
    amount:Decimal=Field(ge=0,max_digits=18,decimal_places=2)
    currency:str=Field(pattern=r'^[A-Z]{3}$')
    occurred_on:date
    source_reference:str=Field(min_length=2,max_length=240)

class ForecastInput(BaseModel):
    remaining_cost:Decimal=Field(ge=0,max_digits=18,decimal_places=2)
    currency:str=Field(pattern=r'^[A-Z]{3}$')
    source_reference:str=Field(min_length=2,max_length=240)
    as_of:date

def register_cost_api(app,db,current_user,member,Project):
    DB=Annotated[Session,Depends(db)]
    UserDep=Annotated[object,Depends(current_user)]
    prefix='/api/companies/{company_id}/projects/{project_id}/costs'
    def scope(session,user,cid,pid,write=False):
        m=member(session,user,cid)
        permission=Permission.PROJECT_CREATE if write else Permission.PROJECT_READ
        if not authorized(m.role,permission,member_company_id=m.company_id,resource_company_id=cid):raise HTTPException(403,'Forbidden')
        if session.scalar(select(Project.id).where(Project.id==pid,Project.company_id==cid)) is None:raise HTTPException(404,'Project not found')
    def get_budget(session,cid,pid):
        return session.scalar(select(ProjectBudget).where(ProjectBudget.company_id==cid,ProjectBudget.project_id==pid))
    @app.put(prefix+'/budget')
    def save_budget(company_id:int,project_id:int,data:BudgetInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        existing=get_budget(session,company_id,project_id)
        entries=list(session.scalars(select(ProjectCostEntry).where(ProjectCostEntry.company_id==company_id,ProjectCostEntry.project_id==project_id)))
        if any(e.currency!=data.currency for e in entries):raise HTTPException(409,'Budget currency conflicts with recorded costs')
        if existing is None:
            existing=ProjectBudget(company_id=company_id,project_id=project_id,currency=data.currency,approved_amount=data.approved_amount)
            session.add(existing)
        else:
            existing.currency=data.currency;existing.approved_amount=data.approved_amount
        session.commit()
        return summarize_budget(existing,entries)
    @app.post(prefix+'/entries',status_code=201)
    def create_entry(company_id:int,project_id:int,data:CostInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        budget=get_budget(session,company_id,project_id)
        if budget is None:raise HTTPException(409,'Create a budget first')
        if budget.currency!=data.currency:raise HTTPException(422,'Cost currency must match budget')
        entry=ProjectCostEntry(company_id=company_id,project_id=project_id,**data.model_dump())
        session.add(entry);session.commit();session.refresh(entry)
        return {'id':entry.id,'kind':entry.kind,'amount':str(entry.amount),'currency':entry.currency,'source_reference':entry.source_reference}
    @app.get(prefix)
    def read_costs(company_id:int,project_id:int,user:UserDep,session:DB):
        scope(session,user,company_id,project_id)
        budget=get_budget(session,company_id,project_id)
        entries=list(session.scalars(select(ProjectCostEntry).where(ProjectCostEntry.company_id==company_id,ProjectCostEntry.project_id==project_id).order_by(ProjectCostEntry.id)))
        return {'summary':summarize_budget(budget,entries) if budget else None,'entries':[{'id':e.id,'kind':e.kind,'description':e.description,'amount':str(e.amount),'currency':e.currency,'occurred_on':e.occurred_on.isoformat(),'source_reference':e.source_reference} for e in entries]}

    @app.post(prefix+'/forecasts',status_code=201)
    def create_forecast(company_id:int,project_id:int,data:ForecastInput,user:UserDep,session:DB):
        scope(session,user,company_id,project_id,True)
        budget=get_budget(session,company_id,project_id)
        if budget is None:raise HTTPException(409,'Create a budget first')
        if data.currency!=budget.currency:raise HTTPException(422,'Forecast currency must match budget')
        item=ProjectCostForecast(company_id=company_id,project_id=project_id,recorded_by=user.id,**data.model_dump())
        session.add(item);session.commit();session.refresh(item)
        entries=list(session.scalars(select(ProjectCostEntry).where(ProjectCostEntry.company_id==company_id,ProjectCostEntry.project_id==project_id)))
        return forecast_completion(budget,entries,item)

    @app.get(prefix+'/forecasts')
    def list_forecasts(company_id:int,project_id:int,user:UserDep,session:DB):
        scope(session,user,company_id,project_id)
        budget=get_budget(session,company_id,project_id)
        if budget is None:return []
        entries=list(session.scalars(select(ProjectCostEntry).where(ProjectCostEntry.company_id==company_id,ProjectCostEntry.project_id==project_id)))
        forecasts=session.scalars(select(ProjectCostForecast).where(ProjectCostForecast.company_id==company_id,ProjectCostForecast.project_id==project_id).order_by(ProjectCostForecast.id.desc()))
        return [forecast_completion(budget,entries,item) for item in forecasts]
