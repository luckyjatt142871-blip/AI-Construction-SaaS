"""Tenant-scoped 5D project budget and actual-cost ledger."""
from sqlalchemy import ForeignKey, String, Numeric, Date, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.main import Base

class ProjectBudget(Base):
    __tablename__='project_budgets'
    __table_args__=(UniqueConstraint('company_id','project_id',name='uq_project_budget_scope'),CheckConstraint('approved_amount >= 0',name='ck_budget_nonnegative'))
    id:Mapped[int]=mapped_column(primary_key=True)
    company_id:Mapped[int]=mapped_column(ForeignKey('companies.id'),nullable=False,index=True)
    project_id:Mapped[int]=mapped_column(ForeignKey('projects.id'),nullable=False,index=True)
    currency:Mapped[str]=mapped_column(String(3),nullable=False)
    approved_amount:Mapped[object]=mapped_column(Numeric(18,2),nullable=False)

class ProjectCostEntry(Base):
    __tablename__='project_cost_entries'
    __table_args__=(CheckConstraint('amount >= 0',name='ck_cost_nonnegative'),CheckConstraint("kind IN ('actual','committed')",name='ck_cost_kind'))
    id:Mapped[int]=mapped_column(primary_key=True)
    company_id:Mapped[int]=mapped_column(ForeignKey('companies.id'),nullable=False,index=True)
    project_id:Mapped[int]=mapped_column(ForeignKey('projects.id'),nullable=False,index=True)
    kind:Mapped[str]=mapped_column(String(12),nullable=False)
    description:Mapped[str]=mapped_column(String(240),nullable=False)
    amount:Mapped[object]=mapped_column(Numeric(18,2),nullable=False)
    currency:Mapped[str]=mapped_column(String(3),nullable=False)
    occurred_on:Mapped[object]=mapped_column(Date(),nullable=False)
    source_reference:Mapped[str]=mapped_column(String(240),nullable=False)


class ProjectCostForecast(Base):
    """Versioned, user-supplied remaining-cost assumption; never inferred from commitments."""
    __tablename__ = 'project_cost_forecasts'
    __table_args__ = (CheckConstraint('remaining_cost >= 0', name='ck_forecast_remaining_nonnegative'),)
    id:Mapped[int] = mapped_column(primary_key=True)
    company_id:Mapped[int] = mapped_column(ForeignKey('companies.id'), nullable=False, index=True)
    project_id:Mapped[int] = mapped_column(ForeignKey('projects.id'), nullable=False, index=True)
    remaining_cost:Mapped[object] = mapped_column(Numeric(18,2), nullable=False)
    currency:Mapped[str] = mapped_column(String(3), nullable=False)
    source_reference:Mapped[str] = mapped_column(String(240), nullable=False)
    recorded_by:Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    as_of:Mapped[object] = mapped_column(Date(), nullable=False)
