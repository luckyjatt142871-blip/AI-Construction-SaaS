"""Real, persisted project metrics; no fabricated portfolio values."""
from typing import Annotated
from fastapi import Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.authorization import authorized, Permission
from app.workspace_models import Drawing, Measurement, Estimate
from app.schedule_models import ScheduleActivity
from app.cost_models import ProjectBudget, ProjectCostEntry
from app.issue_models import ProjectIssue
from app.rfi_models import ProjectRFI

def register_project_overview(app, db, current_user, member, Project):
    DB = Annotated[Session, Depends(db)]
    UserDep = Annotated[object, Depends(current_user)]
    @app.get('/api/companies/{company_id}/projects/{project_id}/overview')
    def overview(company_id: int, project_id: int, user: UserDep, session: DB):
        m = member(session, user, company_id)
        if not authorized(m.role, Permission.PROJECT_READ, member_company_id=m.company_id, resource_company_id=company_id):
            raise HTTPException(403, 'Forbidden')
        if session.scalar(select(Project.id).where(Project.id == project_id, Project.company_id == company_id)) is None:
            raise HTTPException(404, 'Project not found')
        def count(model, *filters):
            return session.scalar(select(func.count(model.id)).where(model.company_id == company_id, model.project_id == project_id, *filters)) or 0
        budget = session.scalar(select(ProjectBudget).where(ProjectBudget.company_id == company_id, ProjectBudget.project_id == project_id))
        entries = session.scalars(select(ProjectCostEntry).where(ProjectCostEntry.company_id == company_id, ProjectCostEntry.project_id == project_id)).all()
        currency = budget.currency if budget else (entries[0].currency if entries else None)
        # Financial totals are only comparable when their currencies match.
        mixed = any(entry.currency != currency for entry in entries)
        return {'drawings':count(Drawing),'measurements':count(Measurement),
                'estimates':count(Estimate),'approved_estimates':count(Estimate,Estimate.status == 'APPROVED'),
                'activities':count(ScheduleActivity),'issues_open':count(ProjectIssue,ProjectIssue.status != 'resolved'),
                'rfis_open':count(ProjectRFI,ProjectRFI.status == 'open'),
                'budget':str(budget.approved_amount) if budget else None,
                'currency':currency,'costs_comparable':not mixed,
                'actual':str(sum((e.amount for e in entries if e.kind == 'actual'),start=0)) if not mixed else None,
                'committed':str(sum((e.amount for e in entries if e.kind == 'committed'),start=0)) if not mixed else None}
