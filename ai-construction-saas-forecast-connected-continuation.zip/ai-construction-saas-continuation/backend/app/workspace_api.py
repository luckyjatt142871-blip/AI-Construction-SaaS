"""Tenant-authorized project, drawing, quantity, rate, and estimate endpoints."""
import hashlib
import json
import os
import secrets
from decimal import Decimal
from datetime import datetime, timezone
from io import BytesIO
from fastapi.responses import StreamingResponse
from pathlib import Path
from typing import Annotated
from fastapi import Depends, HTTPException, UploadFile, File, Response
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.workspace_models import Drawing, Measurement, RateItem, Estimate, EstimateLine, DrawingCalibration
from app.workspace_calculations import measure, rate_total, line_amount
from app.calibration_rules import calibrated_quantity
from app.estimate_integrity import validate_rate_date, validate_line_snapshot
from app.authorization import authorized, Permission

class ProjectPatch(BaseModel):
    name: str = Field(min_length=2, max_length=200)
class Calibration(BaseModel):
    page_number: int = Field(default=1, ge=1, le=300)
    known_meters: Decimal = Field(gt=0, le=100000)
    pixel_distance: Decimal = Field(gt=0, le=1000000)
class MeasureInput(BaseModel):
    drawing_id: int
    page_number: int = Field(default=1, ge=1, le=300)
    kind: str
    points: list[list[float]] = Field(min_length=1, max_length=500)
class RateInput(BaseModel):
    code: str = Field(min_length=1, max_length=50)
    description: str = Field(min_length=2, max_length=250)
    unit: str = Field(min_length=1, max_length=10)
    material: Decimal = Field(ge=0)
    labour: Decimal = Field(ge=0)
    equipment: Decimal = Field(ge=0)
    currency: str = Field(pattern=r'^[A-Z]{3}$')
    provenance: str = Field(min_length=3, max_length=250)
    rate_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")

    @field_validator("rate_date")
    @classmethod
    def check_rate_date(cls, value: str) -> str:
        return validate_rate_date(value)
class EstimateInput(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    currency: str = Field(pattern=r'^[A-Z]{3}$')
class LineInput(BaseModel):
    measurement_id: int
    rate_id: int

from app.document_validation import validate_document, MAX_UPLOAD
from app.pdf_pages import raster_metadata, render_pdf_page, image_dimensions

def register_workspace(app, db, current_user, member, Project, AuditLog, settings):
    DB = Annotated[Session, Depends(db)]
    UserDep = Annotated[object, Depends(current_user)]
    def require(session, user, cid, permission=Permission.PROJECT_READ):
        m = member(session, user, cid)
        if not authorized(m.role, permission, member_company_id=m.company_id, resource_company_id=cid):
            raise HTTPException(403, 'Insufficient permissions')
        return m
    def project_or_404(session, cid, pid):
        obj = session.scalar(select(Project).where(Project.id == pid, Project.company_id == cid))
        if obj is None: raise HTTPException(404, 'Project not found')
        return obj
    def drawing_or_404(session, cid, pid, did):
        obj = session.scalar(select(Drawing).where(Drawing.id == did, Drawing.company_id == cid, Drawing.project_id == pid))
        if obj is None: raise HTTPException(404, 'Drawing not found')
        return obj
    @app.get('/api/companies/{company_id}/projects')
    def list_projects(company_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        return [{'id': p.id, 'name': p.name} for p in session.scalars(select(Project).where(Project.company_id == company_id).order_by(Project.id.desc()))]
    @app.patch('/api/companies/{company_id}/projects/{project_id}')
    def rename_project(company_id: int, project_id: int, data: ProjectPatch, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        p = project_or_404(session, company_id, project_id)
        p.name = data.name
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='project.renamed'))
        session.commit()
        return {'id': p.id, 'name': p.name}
    @app.post('/api/companies/{company_id}/projects/{project_id}/drawings', status_code=201)
    async def upload_drawing(company_id: int, project_id: int, user: UserDep, session: DB, file: UploadFile = File(...)):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        project_or_404(session, company_id, project_id)
        data = await file.read(MAX_UPLOAD + 1)
        try: digest = validate_document(data, file.content_type or '')
        except ValueError as exc: raise HTTPException(415, str(exc)) from exc
        # Validate document structure and native dimensions before persisting.
        try:
            meta = raster_metadata(data) if file.content_type == 'application/pdf' else image_dimensions(data)
        except ValueError as exc: raise HTTPException(422, str(exc)) from exc
        # Local private storage is a development adapter, not production object storage.
        root = Path(os.environ.get('PRIVATE_STORAGE_ROOT', '/tmp/estimator-private'))
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        key = secrets.token_hex(24)
        path = root / key
        with path.open('xb') as out: out.write(data)
        os.chmod(path, 0o600)
        d = Drawing(company_id=company_id, project_id=project_id, name=(file.filename or 'drawing')[:200], object_key=key, sha256=digest, size_bytes=len(data), media_type=file.content_type)
        session.add(d)
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='drawing.uploaded'))
        session.commit()
        return {'id': d.id, 'name': d.name, 'sha256': d.sha256, **meta}
    @app.get('/api/companies/{company_id}/projects/{project_id}/drawings')
    def list_drawings(company_id: int, project_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        project_or_404(session, company_id, project_id)
        return [{'id': d.id, 'name': d.name, 'media_type': d.media_type, 'revision': d.revision, 'scale_m_per_pixel': None} for d in session.scalars(select(Drawing).where(Drawing.company_id == company_id, Drawing.project_id == project_id))]
    def invalid_page():
        raise ValueError('Page out of range')
    def read_private_drawing(d):
        path = Path(os.environ.get('PRIVATE_STORAGE_ROOT', '/tmp/estimator-private')) / d.object_key
        try: data = path.read_bytes()
        except FileNotFoundError: raise HTTPException(404, 'Stored object unavailable')
        if hashlib.sha256(data).hexdigest() != d.sha256: raise HTTPException(409, 'Storage integrity failure')
        return data

    @app.get('/api/companies/{company_id}/projects/{project_id}/drawings/{drawing_id}/file')
    def get_drawing(company_id: int, project_id: int, drawing_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        d = drawing_or_404(session, company_id, project_id, drawing_id)
        data = read_private_drawing(d)
        return Response(data, media_type=d.media_type, headers={'Content-Disposition': 'inline', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})
    @app.get('/api/companies/{company_id}/projects/{project_id}/drawings/{drawing_id}/pages/{page_number}/metadata')
    def drawing_page_metadata(company_id: int, project_id: int, drawing_id: int, page_number: int, user: UserDep, session: DB):
        require(session, user, company_id)
        d = drawing_or_404(session, company_id, project_id, drawing_id)
        blob = read_private_drawing(d)
        try:
            return raster_metadata(blob, page_number) if d.media_type == 'application/pdf' else image_dimensions(blob) if page_number == 1 else invalid_page()
        except ValueError as exc: raise HTTPException(422, str(exc)) from exc

    @app.get('/api/companies/{company_id}/projects/{project_id}/drawings/{drawing_id}/pages/{page_number}/raster')
    def drawing_page_raster(company_id: int, project_id: int, drawing_id: int, page_number: int, user: UserDep, session: DB):
        require(session, user, company_id)
        d = drawing_or_404(session, company_id, project_id, drawing_id)
        blob = read_private_drawing(d)
        try:
            if d.media_type == 'application/pdf':
                png, meta = render_pdf_page(blob, page_number)
                return Response(png, media_type='image/png', headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})
            if page_number != 1: raise ValueError('Page out of range')
            image_dimensions(blob)
            return Response(blob, media_type=d.media_type, headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})
        except ValueError as exc: raise HTTPException(422, str(exc)) from exc

    def page_meta(d, page_number):
        blob = read_private_drawing(d)
        try:
            return raster_metadata(blob, page_number) if d.media_type == 'application/pdf' else image_dimensions(blob) if page_number == 1 else invalid_page()
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    def page_scale(session, d, page_number):
        return session.scalar(select(DrawingCalibration).where(
            DrawingCalibration.company_id == d.company_id,
            DrawingCalibration.project_id == d.project_id,
            DrawingCalibration.drawing_id == d.id,
            DrawingCalibration.drawing_revision == d.revision,
            DrawingCalibration.page_number == page_number
        ).order_by(DrawingCalibration.version.desc()).limit(1))

    def validate_points(points, meta):
        if any(x > meta['width'] or y > meta['height'] for x,y in points):
            raise HTTPException(422, 'Point lies outside native drawing page')

    @app.get('/api/companies/{company_id}/projects/{project_id}/drawings/{drawing_id}/pages/{page_number}/calibration')
    def get_page_calibration(company_id: int, project_id: int, drawing_id: int, page_number: int, user: UserDep, session: DB):
        require(session, user, company_id)
        d = drawing_or_404(session, company_id, project_id, drawing_id)
        page_meta(d, page_number)
        c = page_scale(session, d, page_number)
        return {'drawing_revision': d.revision, 'page_number': page_number, 'calibration_id': c.id if c else None, 'scale_m_per_pixel': str(c.scale_m_per_pixel) if c else None, 'version': c.version if c else None}

    @app.post('/api/companies/{company_id}/projects/{project_id}/drawings/{drawing_id}/calibrate')
    def calibrate(company_id: int, project_id: int, drawing_id: int, data: Calibration, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        d = session.scalar(select(Drawing).where(Drawing.id == drawing_id, Drawing.company_id == company_id, Drawing.project_id == project_id).with_for_update())
        if d is None: raise HTTPException(404, 'Drawing not found')
        page_meta(d, data.page_number)
        current = page_scale(session, d, data.page_number)
        scale = data.known_meters / data.pixel_distance
        if scale <= 0 or scale > 1000: raise HTTPException(422, 'Invalid calibration scale')
        c = DrawingCalibration(company_id=company_id, project_id=project_id, drawing_id=d.id, drawing_revision=d.revision, page_number=data.page_number, version=(current.version + 1 if current else 1), scale_m_per_pixel=scale, known_meters=data.known_meters, pixel_distance=data.pixel_distance)
        session.add(c); session.flush()
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='drawing.page_calibrated'))
        session.commit()
        return {'calibration_id': c.id, 'drawing_revision': d.revision, 'page_number': data.page_number, 'version': c.version, 'scale_m_per_pixel': str(c.scale_m_per_pixel)}

    @app.post('/api/companies/{company_id}/projects/{project_id}/measurements', status_code=201)
    def create_measurement(company_id: int, project_id: int, data: MeasureInput, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        d = drawing_or_404(session, company_id, project_id, data.drawing_id)
        meta = page_meta(d, data.page_number)
        validate_points(data.points, meta)
        c = page_scale(session, d, data.page_number)
        if c is None: raise HTTPException(422, 'This drawing page and revision must be calibrated before measuring')
        try: qty, unit = calibrated_quantity(data.kind, data.points, calibration=c, drawing_id=d.id, drawing_revision=d.revision, page_number=data.page_number, width=meta['width'], height=meta['height'])
        except ValueError as exc: raise HTTPException(422, str(exc)) from exc
        m = Measurement(company_id=company_id, project_id=project_id, drawing_id=d.id, calibration_id=c.id, drawing_revision=d.revision, kind=data.kind, page_number=data.page_number, points_json=json.dumps(data.points), quantity=qty, unit=unit)
        session.add(m); session.commit()
        return {'id': m.id, 'quantity': str(qty), 'unit': unit}
    @app.get('/api/companies/{company_id}/projects/{project_id}/measurements')
    def list_measurements(company_id: int, project_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        project_or_404(session, company_id, project_id)
        return [{'id': m.id, 'drawing_id': m.drawing_id, 'page_number': m.page_number, 'calibration_id': m.calibration_id, 'drawing_revision': m.drawing_revision, 'kind': m.kind, 'points': json.loads(m.points_json), 'quantity': str(m.quantity), 'unit': m.unit} for m in session.scalars(select(Measurement).where(Measurement.company_id == company_id, Measurement.project_id == project_id))]
    @app.put('/api/companies/{company_id}/projects/{project_id}/measurements/{measurement_id}')
    def update_measurement(company_id: int, project_id: int, measurement_id: int, data: MeasureInput, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        m = session.scalar(select(Measurement).where(Measurement.id == measurement_id, Measurement.company_id == company_id, Measurement.project_id == project_id))
        if m is None: raise HTTPException(404, 'Measurement not found')
        d = drawing_or_404(session, company_id, project_id, data.drawing_id)
        meta = page_meta(d, data.page_number)
        validate_points(data.points, meta)
        c = page_scale(session, d, data.page_number)
        if c is None: raise HTTPException(422, 'This drawing page and revision must be calibrated before measuring')
        try: qty, unit = calibrated_quantity(data.kind, data.points, calibration=c, drawing_id=d.id, drawing_revision=d.revision, page_number=data.page_number, width=meta['width'], height=meta['height'])
        except ValueError as exc: raise HTTPException(422, str(exc)) from exc
        m.drawing_id=d.id; m.calibration_id=c.id; m.drawing_revision=d.revision; m.page_number=data.page_number; m.kind=data.kind; m.points_json=json.dumps(data.points); m.quantity=qty; m.unit=unit; m.revision+=1
        session.commit()
        return {'id': m.id, 'quantity': str(qty), 'unit': unit, 'revision': m.revision}
    @app.post('/api/companies/{company_id}/rates', status_code=201)
    def add_rate(company_id: int, data: RateInput, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        try: rate_total(data.material, data.labour, data.equipment)
        except ValueError as exc: raise HTTPException(422, str(exc)) from exc
        r = RateItem(company_id=company_id, **data.model_dump())
        session.add(r); session.commit()
        return {'id': r.id, 'code': r.code}
    @app.get('/api/companies/{company_id}/rates')
    def list_rates(company_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        return [{'id': r.id, 'code': r.code, 'description': r.description, 'unit': r.unit, 'currency': r.currency, 'unit_rate': str(rate_total(r.material, r.labour, r.equipment)), 'provenance': r.provenance, 'rate_date': r.rate_date} for r in session.scalars(select(RateItem).where(RateItem.company_id == company_id))]
    @app.post('/api/companies/{company_id}/projects/{project_id}/estimates', status_code=201)
    def create_estimate(company_id: int, project_id: int, data: EstimateInput, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        project_or_404(session, company_id, project_id)
        e = Estimate(company_id=company_id, project_id=project_id, **data.model_dump())
        session.add(e); session.commit()
        return {'id': e.id, 'name': e.name}
    @app.post('/api/companies/{company_id}/projects/{project_id}/estimates/{estimate_id}/lines', status_code=201)
    def add_estimate_line(company_id: int, project_id: int, estimate_id: int, data: LineInput, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        e = session.scalar(select(Estimate).where(Estimate.id == estimate_id, Estimate.company_id == company_id, Estimate.project_id == project_id))
        m = session.scalar(select(Measurement).where(Measurement.id == data.measurement_id, Measurement.company_id == company_id, Measurement.project_id == project_id))
        r = session.scalar(select(RateItem).where(RateItem.id == data.rate_id, RateItem.company_id == company_id))
        if e is None or m is None or r is None: raise HTTPException(404, 'Estimate input not found')
        if e.status != 'DRAFT': raise HTTPException(409, 'Estimate is locked')
        if m.calibration_id is None: raise HTTPException(422, 'Unverified quantity cannot be estimated')
        if not r.rate_date: raise HTTPException(422, 'Rate date required')
        if m.unit != r.unit or e.currency != r.currency: raise HTTPException(422, 'Unit or currency mismatch')
        unit_rate = rate_total(r.material, r.labour, r.equipment)
        amount = line_amount(m.quantity, unit_rate)
        line = EstimateLine(company_id=company_id, estimate_id=e.id, measurement_id=m.id, rate_id=r.id, quantity=m.quantity, unit_rate=unit_rate, amount=amount)
        session.add(line); session.commit()
        return {'id': line.id, 'amount': str(amount)}
    @app.get('/api/companies/{company_id}/projects/{project_id}/estimates/{estimate_id}/boq')
    def boq(company_id: int, project_id: int, estimate_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        e = session.scalar(select(Estimate).where(Estimate.id == estimate_id, Estimate.company_id == company_id, Estimate.project_id == project_id))
        if e is None: raise HTTPException(404, 'Estimate not found')
        lines = session.scalars(select(EstimateLine).where(EstimateLine.company_id == company_id, EstimateLine.estimate_id == e.id).order_by(EstimateLine.id)).all()
        rows = [{'item': i, 'quantity': str(l.quantity), 'unit_rate': str(l.unit_rate), 'amount': str(l.amount), 'measurement_id': l.measurement_id, 'rate_id': l.rate_id} for i,l in enumerate(lines, 1)]
        return {'estimate_id': e.id, 'currency': e.currency, 'lines': rows, 'total': str(sum((l.amount for l in lines), Decimal('0.00')))}

    @app.get('/api/companies/{company_id}/projects/{project_id}/estimates')
    def list_estimates(company_id: int, project_id: int, user: UserDep, session: DB):
        require(session, user, company_id)
        project_or_404(session, company_id, project_id)
        return [{'id': e.id, 'name': e.name, 'currency': e.currency, 'status': e.status, 'revision': e.revision} for e in session.scalars(select(Estimate).where(Estimate.company_id == company_id, Estimate.project_id == project_id))]

    def estimate_boq(session, company_id, project_id, estimate_id):
        e = session.scalar(select(Estimate).where(Estimate.id == estimate_id, Estimate.company_id == company_id, Estimate.project_id == project_id))
        if e is None: raise HTTPException(404, 'Estimate not found')
        lines = session.scalars(select(EstimateLine).where(EstimateLine.company_id == company_id, EstimateLine.estimate_id == e.id).order_by(EstimateLine.id)).all()
        return e, [{'item': i, 'quantity': str(l.quantity), 'unit_rate': str(l.unit_rate), 'amount': str(l.amount), 'measurement_id': l.measurement_id, 'rate_id': l.rate_id} for i,l in enumerate(lines, 1)]

    @app.post('/api/companies/{company_id}/projects/{project_id}/estimates/{estimate_id}/approve')
    def approve_estimate(company_id: int, project_id: int, estimate_id: int, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        e = session.scalar(select(Estimate).where(Estimate.id == estimate_id, Estimate.company_id == company_id, Estimate.project_id == project_id).with_for_update())
        if e is None: raise HTTPException(404, 'Estimate not found')
        if e.status != 'DRAFT': raise HTTPException(409, 'Only draft estimates can be approved')
        lines = session.scalars(select(EstimateLine).where(EstimateLine.company_id == company_id, EstimateLine.estimate_id == e.id)).all()
        if not lines: raise HTTPException(422, 'Cannot approve empty estimate')
        for line in lines:
            m = session.scalar(select(Measurement).where(Measurement.id == line.measurement_id, Measurement.company_id == company_id, Measurement.project_id == project_id))
            r = session.scalar(select(RateItem).where(RateItem.id == line.rate_id, RateItem.company_id == company_id))
            c = session.scalar(select(DrawingCalibration).where(DrawingCalibration.id == m.calibration_id, DrawingCalibration.company_id == company_id, DrawingCalibration.project_id == project_id)) if m and m.calibration_id else None
            try:
                validate_line_snapshot(line, m, r, c, currency=e.currency)
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc
        e.status = 'APPROVED'; e.approved_by = user.id; e.approved_at = datetime.now(timezone.utc).isoformat()
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='estimate.approved'))
        session.commit()
        return {'id': e.id, 'status': e.status, 'approved_at': e.approved_at}

    @app.post('/api/companies/{company_id}/projects/{project_id}/estimates/{estimate_id}/revise', status_code=201)
    def revise_estimate(company_id: int, project_id: int, estimate_id: int, user: UserDep, session: DB):
        require(session, user, company_id, Permission.PROJECT_CREATE)
        e, _ = estimate_boq(session, company_id, project_id, estimate_id)
        if e.status != 'APPROVED': raise HTTPException(409, 'Only approved estimates can be revised')
        new = Estimate(company_id=company_id, project_id=project_id, name=e.name, currency=e.currency, status='DRAFT', revision=e.revision+1)
        session.add(new); session.flush()
        for old in session.scalars(select(EstimateLine).where(EstimateLine.company_id == company_id, EstimateLine.estimate_id == e.id)):
            session.add(EstimateLine(company_id=company_id, estimate_id=new.id, measurement_id=old.measurement_id, rate_id=old.rate_id, quantity=old.quantity, unit_rate=old.unit_rate, amount=old.amount))
        session.add(AuditLog(company_id=company_id, actor_id=user.id, action='estimate.revised'))
        session.commit()
        return {'id': new.id, 'revision': new.revision, 'status': new.status}

    @app.get('/api/companies/{company_id}/projects/{project_id}/estimates/{estimate_id}/export/{format}')
    def export_boq(company_id: int, project_id: int, estimate_id: int, format: str, user: UserDep, session: DB):
        require(session, user, company_id)
        e, rows = estimate_boq(session, company_id, project_id, estimate_id)
        if e.status != 'APPROVED': raise HTTPException(409, 'Only approved estimates can be exported')
        from app.boq_exports import export_excel, export_pdf
        if format == 'xlsx':
            body = export_excel(e.name, e.currency, rows)
            mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        elif format == 'pdf':
            body = export_pdf(e.name, e.currency, rows)
            mime = 'application/pdf'
        else: raise HTTPException(404, 'Unsupported export format')
        return StreamingResponse(BytesIO(body), media_type=mime, headers={'Content-Disposition': f'attachment; filename="estimate-{e.id}.{format}"', 'Cache-Control':'no-store'})
