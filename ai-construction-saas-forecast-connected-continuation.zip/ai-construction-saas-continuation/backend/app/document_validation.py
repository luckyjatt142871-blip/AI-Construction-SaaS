import hashlib

ALLOWED = {'application/pdf': b'%PDF-', 'image/png': b'\x89PNG\r\n\x1a\n', 'image/jpeg': b'\xff\xd8\xff'}
MAX_UPLOAD = 20 * 1024 * 1024

def validate_document(data: bytes, mime: str):
    if not data or len(data) > MAX_UPLOAD or mime not in ALLOWED or not data.startswith(ALLOWED[mime]):
        raise ValueError('Unsupported, empty, or oversized file')
    # Magic header alone is insufficient for malware detection; quarantine and scanning required before production.
    return hashlib.sha256(data).hexdigest()
