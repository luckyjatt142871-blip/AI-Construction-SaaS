"""Coordinate conversion for a drawing page's intrinsic pixel coordinate space.

No canvas size, CSS size, device pixel ratio, or zoom is ever persisted as a quantity.
"""
from math import hypot, isfinite


def screen_to_native(client_x, client_y, rect, native_width, native_height, view_box):
    """Map pointer position to native pixels, respecting SVG meet letterboxing.

    rect: (left, top, CSS width, CSS height); view_box: (x,y,width,height)
    Raises on clicks outside the image, rather than silently inventing coordinates.
    """
    left, top, css_w, css_h = map(float, rect)
    x, y, vw, vh = map(float, view_box)
    if not all(isfinite(v) for v in (left, top, css_w, css_h, x, y, vw, vh)):
        raise ValueError('Non-finite viewport')
    if min(css_w, css_h, vw, vh, native_width, native_height) <= 0:
        raise ValueError('Invalid viewport dimensions')
    factor = min(css_w / vw, css_h / vh)
    rendered_w, rendered_h = vw * factor, vh * factor
    pad_x, pad_y = (css_w-rendered_w)/2, (css_h-rendered_h)/2
    sx = (float(client_x)-left-pad_x)/factor + x
    sy = (float(client_y)-top-pad_y)/factor + y
    if not (0 <= sx <= native_width and 0 <= sy <= native_height):
        raise ValueError('Click outside drawing')
    return (sx, sy)


def calibration_scale(point_a, point_b, known_meters):
    distance = hypot(float(point_a[0])-float(point_b[0]), float(point_a[1])-float(point_b[1]))
    if not isfinite(distance) or distance <= 0 or not isfinite(float(known_meters)) or float(known_meters) <= 0:
        raise ValueError('Invalid calibration')
    return float(known_meters) / distance
