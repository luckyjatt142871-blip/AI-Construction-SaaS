"""Pure validated 2D measurements and deterministic money calculations."""
from decimal import Decimal, ROUND_HALF_UP
from math import hypot, isfinite

def measure(kind, points, scale):
    if kind not in ('length', 'area', 'polygon', 'count'):
        raise ValueError('Unsupported measurement type')
    if not isinstance(points, list) or len(points) > 500 or any(not isinstance(p, list) or len(p) != 2 or any(not isinstance(v, (int,float)) or not isfinite(v) or v < 0 or v > 1000000 for v in p) for p in points):
        raise ValueError('Invalid coordinates')
    if kind == 'count':
        if not points: raise ValueError('At least one point required')
        return Decimal(len(points)), 'ea'
    scale = Decimal(str(scale)) if scale is not None else Decimal(0)
    if not scale.is_finite() or scale <= 0 or scale > 1000:
        raise ValueError('Drawing must have a valid calibrated scale')
    if kind == 'length':
        if len(points) != 2: raise ValueError('Length needs two points')
        value = Decimal(str(hypot(points[1][0]-points[0][0], points[1][1]-points[0][1]))) * scale
        return value.quantize(Decimal('0.000001')), 'm'
    if len(points) < 3: raise ValueError('Polygon needs at least three vertices')
    from app.engines.quantities import polygon_area
    # Existing engine rejects self-intersecting polygons and zero-area geometry.
    area = polygon_area([(Decimal(str(x)), Decimal(str(y))) for x,y in points])
    return (area * scale * scale).quantize(Decimal('0.000001')), 'm2'

def rate_total(material, labour, equipment):
    values = [Decimal(str(x)) for x in (material, labour, equipment)]
    if any(not x.is_finite() or x < 0 for x in values): raise ValueError('Rates must be finite and nonnegative')
    return sum(values)

def line_amount(quantity, rate):
    q, r = Decimal(str(quantity)), Decimal(str(rate))
    if not q.is_finite() or not r.is_finite() or q < 0 or r < 0: raise ValueError('Invalid quantity or rate')
    return (q*r).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
