"""Tenant-owned requests for information and project correspondence."""
from datetime import datetime, timezone
from sqlalchemy import ForeignKey, String, Text, DateTime, UniqueConstraint, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.main import Base

class ProjectRFI(Base):
    __tablename__ = 'project_rfis'
    __table_args__ = (
        UniqueConstraint('company_id', 'project_id', 'reference', name='uq_project_rfi_reference'),
        CheckConstraint("status IN ('open','answered','closed')", name='ck_project_rfi_status'),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('companies.id'), nullable=False, index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('projects.id'), nullable=False, index=True)
    reference: Mapped[str] = mapped_column(String(50), nullable=False)
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    question: Mapped[str] = mapped_column(Text, nullable=False)
    answer: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(12), nullable=False, default='open')
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    answered_by: Mapped[int | None] = mapped_column(ForeignKey('users.id'), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    answered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
