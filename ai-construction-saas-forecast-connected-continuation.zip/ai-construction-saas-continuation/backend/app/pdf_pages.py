"""Render one untrusted PDF page in a constrained worker process.

Page pixels at RENDER_DPI are the canonical takeoff coordinate space. Rendering
never executes PDF JavaScript. Sandbox this operation at the container level too.
"""
import io
from PIL import Image

RENDER_DPI = 144
MAX_PAGES = 300
MAX_PAGE_PIXELS = 25_000_000


def raster_metadata(blob: bytes, page_number: int = 1):
    import fitz
    if not isinstance(page_number, int) or page_number < 1:
        raise ValueError('Invalid page')
    try:
        with fitz.open(stream=blob, filetype='pdf') as doc:
            if doc.needs_pass or doc.page_count > MAX_PAGES or page_number > doc.page_count:
                raise ValueError('PDF encrypted, too long or page out of range')
            page = doc.load_page(page_number-1)
            scale = RENDER_DPI / 72
            width, height = round(page.rect.width * scale), round(page.rect.height * scale)
            if width <= 0 or height <= 0 or width * height > MAX_PAGE_PIXELS:
                raise ValueError('PDF page exceeds rendering limits')
            return {'page': page_number, 'pages': doc.page_count, 'width': width, 'height': height, 'dpi': RENDER_DPI}
    except (RuntimeError, ValueError) as exc:
        raise ValueError('PDF could not be safely inspected') from exc


def render_pdf_page(blob: bytes, page_number: int = 1):
    import fitz
    meta = raster_metadata(blob, page_number)
    with fitz.open(stream=blob, filetype='pdf') as doc:
        pix = doc.load_page(page_number-1).get_pixmap(matrix=fitz.Matrix(RENDER_DPI/72, RENDER_DPI/72), colorspace=fitz.csRGB, alpha=False)
        if pix.width * pix.height > MAX_PAGE_PIXELS:
            raise ValueError('PDF raster exceeds limits')
        # Explicit PNG encode; no user-supplied filename or metadata reflected.
        return pix.tobytes('png'), {**meta, 'width': pix.width, 'height': pix.height}


def image_dimensions(blob: bytes):
    try:
        with Image.open(io.BytesIO(blob)) as img:
            img.verify()
        with Image.open(io.BytesIO(blob)) as img:
            width, height = img.size
            if width <= 0 or height <= 0 or width * height > MAX_PAGE_PIXELS:
                raise ValueError('Image exceeds pixel limit')
            return {'page': 1, 'pages': 1, 'width': width, 'height': height}
    except (OSError, ValueError) as exc:
        raise ValueError('Invalid or oversized image') from exc
