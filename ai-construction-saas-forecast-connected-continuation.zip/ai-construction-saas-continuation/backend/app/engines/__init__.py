"""Deterministic, side-effect-free construction calculation engines."""
