"""Reviewed-input-only quantity calculations. No inferred scale or dimensions.

These functions are independent of AI and of the database. Values are Decimal
so that cost/quantity workflows do not inherit binary floating-point error.
"""
from decimal import Decimal, InvalidOperation
from dataclasses import dataclass
from typing import Sequence


class QuantityError(ValueError):
    pass


def positive(value: str | int | Decimal) -> Decimal:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise QuantityError('Invalid dimension') from exc
    if not number.is_finite() or number <= 0:
        raise QuantityError('Dimensions must be positive and finite')
    return number


def nonnegative(value: str | int | Decimal) -> Decimal:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise QuantityError('Invalid quantity') from exc
    if not number.is_finite() or number < 0:
        raise QuantityError('Quantity must be nonnegative and finite')
    return number


_LENGTH_TO_M = {'mm': Decimal('0.001'), 'cm': Decimal('0.01'),
                'm': Decimal('1'), 'ft': Decimal('0.3048'), 'in': Decimal('0.0254')}


def length(value: str | Decimal, unit: str) -> Decimal:
    if unit not in _LENGTH_TO_M:
        raise QuantityError('Unsupported length unit')
    return positive(value) * _LENGTH_TO_M[unit]


def rectangle_area(width: str | Decimal, height: str | Decimal, unit: str = 'm') -> Decimal:
    return length(width, unit) * length(height, unit)


def rectangular_volume(width: str | Decimal, height: str | Decimal,
                       depth: str | Decimal, unit: str = 'm') -> Decimal:
    return rectangle_area(width, height, unit) * length(depth, unit)


def polygon_area(points: Sequence[tuple[str | Decimal, str | Decimal]], unit: str = 'm') -> Decimal:
    """Shoelace area, assuming a simple polygon. Self-intersections rejected."""
    if unit not in _LENGTH_TO_M or len(points) < 3:
        raise QuantityError('Polygon requires >=3 vertices and a supported unit')
    try:
        vertices = [(Decimal(str(x)), Decimal(str(y))) for x, y in points]
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise QuantityError('Invalid polygon coordinates') from exc
    if any(not x.is_finite() or not y.is_finite() for x, y in vertices):
        raise QuantityError('Non-finite polygon coordinate')
    if len(set(vertices)) != len(vertices):
        raise QuantityError('Duplicate polygon vertices')
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def intersects(a,b,c,d):
        # Strict crossing; collinear overlaps are invalid geometry too.
        ab1,ab2=cross(a,b,c),cross(a,b,d)
        cd1,cd2=cross(c,d,a),cross(c,d,b)
        if ab1 == ab2 == 0:
            return max(min(a[0],b[0]),min(c[0],d[0])) <= min(max(a[0],b[0]),max(c[0],d[0])) and max(min(a[1],b[1]),min(c[1],d[1])) <= min(max(a[1],b[1]),max(c[1],d[1]))
        return (ab1 * ab2 <= 0 and cd1 * cd2 <= 0)
    n=len(vertices)
    for i in range(n):
        for j in range(i+1,n):
            if j == i+1 or (i == 0 and j == n-1):
                continue
            if intersects(vertices[i],vertices[(i+1)%n],vertices[j],vertices[(j+1)%n]):
                raise QuantityError('Self-intersecting polygon')
    twice=sum(vertices[i][0]*vertices[(i+1)%n][1]-vertices[(i+1)%n][0]*vertices[i][1] for i in range(n))
    if twice == 0:
        raise QuantityError('Zero-area polygon')
    return abs(twice) / 2 * _LENGTH_TO_M[unit]**2


def count(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise QuantityError('Count must be a nonnegative integer')
    return value


def apply_waste(quantity: str | Decimal, waste_percent: str | Decimal) -> Decimal:
    q = nonnegative(quantity)
    waste = nonnegative(waste_percent)
    if waste > 100:
        raise QuantityError('Waste over 100% requires explicit exceptional approval')
    return q * (Decimal('1') + waste / Decimal('100'))


def extended_cost(quantity: str | Decimal, unit_rate: str | Decimal) -> Decimal:
    return nonnegative(quantity) * nonnegative(unit_rate)


@dataclass(frozen=True)
class SourceTrace:
    project_id: int
    document_id: int
    page: int
    revision: str
    measurement_method: str
    reviewer_id: int | None

    def __post_init__(self):
        if self.project_id <= 0 or self.document_id <= 0 or self.page < 1 or not self.revision.strip() or not self.measurement_method.strip():
            raise QuantityError('Quantity source trace is incomplete')
