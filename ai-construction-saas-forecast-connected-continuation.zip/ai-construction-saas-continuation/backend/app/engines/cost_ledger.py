"""Pure 5D ledger arithmetic, with no runtime DB or MFA dependencies."""
from decimal import Decimal

def summarize_budget(budget,entries):
    actual=sum((Decimal(str(e.amount)) for e in entries if e.kind=='actual'),Decimal('0'))
    committed=sum((Decimal(str(e.amount)) for e in entries if e.kind=='committed'),Decimal('0'))
    approved=Decimal(str(budget.approved_amount))
    return {'currency':budget.currency,'approved_amount':str(approved),'actual_cost':str(actual),'committed_cost':str(committed),'remaining_after_actual_and_committed':str(approved-actual-committed)}


def forecast_completion(budget, entries, forecast):
    """EAC = recorded actuals + explicitly provided estimate to complete.

    Commitments are shown separately because some may already be included in ETC;
    summing them would double-count costs without reconciliation evidence.
    """
    actual = sum((Decimal(str(e.amount)) for e in entries if e.kind == 'actual'), Decimal('0'))
    etc = Decimal(str(forecast.remaining_cost))
    if etc < 0 or forecast.currency != budget.currency:
        raise ValueError('Forecast must use budget currency and nonnegative remaining cost')
    eac = actual + etc
    return {'currency': budget.currency, 'actual_cost': str(actual),
            'estimate_to_complete': str(etc), 'estimate_at_completion': str(eac),
            'variance_at_completion': str(Decimal(str(budget.approved_amount)) - eac),
            'source_reference': forecast.source_reference, 'as_of': forecast.as_of.isoformat(),
            'forecast_id': forecast.id,
            'method': 'actual_cost_plus_user_supplied_remaining_cost'}
