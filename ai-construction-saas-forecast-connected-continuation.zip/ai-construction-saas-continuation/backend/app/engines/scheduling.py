"""Deterministic finish-to-start construction scheduling calculations.

No calendar, resource leveling, or BIM assumptions are inferred. All durations are
integer working-day offsets; a separate calendar adapter is required for dates.
"""
from dataclasses import dataclass
from collections import deque


@dataclass(frozen=True)
class Activity:
    id: str
    duration_days: int
    predecessors: tuple[str, ...] = ()


@dataclass(frozen=True)
class ScheduleResult:
    id: str
    early_start: int
    early_finish: int
    late_start: int
    late_finish: int
    total_float: int
    critical: bool


def calculate_critical_path(activities: list[Activity]) -> tuple[int, list[ScheduleResult]]:
    """Calculate CPM for a DAG of finish-to-start activities.

    Raises ValueError for duplicate IDs, missing predecessors, self-dependencies,
    cycles, noninteger/negative durations, and invalid predecessor values.
    """
    by_id = {}
    for activity in activities:
        if not isinstance(activity.id, str) or not activity.id.strip() or activity.id in by_id:
            raise ValueError('activity IDs must be nonempty and unique')
        if type(activity.duration_days) is not int or activity.duration_days < 0:
            raise ValueError('duration must be a nonnegative integer')
        if not isinstance(activity.predecessors, tuple) or len(set(activity.predecessors)) != len(activity.predecessors):
            raise ValueError('predecessors must be unique')
        by_id[activity.id] = activity
    successors = {key: [] for key in by_id}
    indegree = {key: 0 for key in by_id}
    for activity in activities:
        for pred in activity.predecessors:
            if pred not in by_id or pred == activity.id:
                raise ValueError('unknown or self predecessor')
            successors[pred].append(activity.id)
            indegree[activity.id] += 1
    ready = deque(a.id for a in activities if indegree[a.id] == 0)
    order = []
    while ready:
        key = ready.popleft()
        order.append(key)
        for next_id in successors[key]:
            indegree[next_id] -= 1
            if indegree[next_id] == 0:
                ready.append(next_id)
    if len(order) != len(activities):
        raise ValueError('schedule contains a dependency cycle')
    es, ef = {}, {}
    for key in order:
        es[key] = max((ef[p] for p in by_id[key].predecessors), default=0)
        ef[key] = es[key] + by_id[key].duration_days
    finish = max(ef.values(), default=0)
    ls, lf = {}, {}
    for key in reversed(order):
        lf[key] = min((ls[s] for s in successors[key]), default=finish)
        ls[key] = lf[key] - by_id[key].duration_days
    return finish, [ScheduleResult(key, es[key], ef[key], ls[key], lf[key], ls[key]-es[key], ls[key] == es[key]) for key in order]
