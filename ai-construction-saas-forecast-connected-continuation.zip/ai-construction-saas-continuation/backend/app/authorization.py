"""Deny-by-default authorization for existing project and audit operations.

A platform role never grants implicit access to another tenant's records.
"""
from enum import Enum

class Permission(str, Enum):
    PROJECT_READ = 'project.read'
    PROJECT_CREATE = 'project.create'
    AUDIT_READ = 'audit.read'

PERMISSIONS = {
    'COMPANY_OWNER': frozenset(Permission),
    'COMPANY_ADMIN': frozenset(Permission),
    'SENIOR_ESTIMATOR': frozenset((Permission.PROJECT_READ, Permission.PROJECT_CREATE)),
    'ESTIMATOR': frozenset((Permission.PROJECT_READ, Permission.PROJECT_CREATE)),
    'QUANTITY_SURVEYOR': frozenset((Permission.PROJECT_READ,)),
    'BIM_MANAGER': frozenset((Permission.PROJECT_READ,)),
    'PROJECT_MANAGER': frozenset((Permission.PROJECT_READ, Permission.PROJECT_CREATE)),
    'REVIEWER': frozenset((Permission.PROJECT_READ,)),
    'CLIENT_VIEWER': frozenset((Permission.PROJECT_READ,)),
}

def authorized(role: str | None, permission: Permission, *, member_company_id: int,
               resource_company_id: int) -> bool:
    return (member_company_id == resource_company_id
            and role in PERMISSIONS
            and permission in PERMISSIONS[role])
