"""Pure calibration invariants shared by validation and regression tests."""
from decimal import Decimal
from math import isfinite

def calibrated_quantity(kind, points, *, calibration, drawing_id, drawing_revision, page_number, width, height):
    if calibration is None:
        raise ValueError('Page has no calibration')
    if (calibration.drawing_id != drawing_id or calibration.drawing_revision != drawing_revision or calibration.page_number != page_number):
        raise ValueError('Calibration belongs to a different drawing, revision or page')
    if not isinstance(width, int) or not isinstance(height, int) or width <= 0 or height <= 0:
        raise ValueError('Invalid native page dimensions')
    if any(not isinstance(p, (list, tuple)) or len(p) != 2 or any(not isinstance(v, (int, float)) or not isfinite(v) for v in p) or p[0] < 0 or p[1] < 0 or p[0] > width or p[1] > height for p in points):
        raise ValueError('Measurement point outside page')
    from app.workspace_calculations import measure
    return measure(kind, points, Decimal(str(calibration.scale_m_per_pixel)))
