"""Verify RLS flags and policy presence on tenant-owned tables."""
from sqlalchemy import create_engine, text
from app.main import settings
TABLES = ('memberships','projects','audit_logs','drawings','measurements','rate_items','estimates','estimate_lines','drawing_calibrations','schedule_activities','schedule_dependencies','project_budgets','project_cost_entries','project_issues','project_rfis')
engine = create_engine(settings.database_url)
with engine.connect() as conn:
    for table in TABLES:
        row = conn.execute(text('SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE oid=to_regclass(:name)'), {'name':table}).first()
        assert row is not None and row[0] and row[1], f'RLS not forced: {table}'
        count = conn.execute(text('SELECT count(*) FROM pg_policies WHERE schemaname=current_schema() AND tablename=:name'), {'name':table}).scalar_one()
        assert count >= 1, f'No policy: {table}'
print('RLS metadata checks passed (NOT an adversarial tenant-isolation test)')
