#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -c 'import pyotp,fastapi,sqlalchemy,alembic,redis; print("Backend imports OK")'
python -m pytest -q
