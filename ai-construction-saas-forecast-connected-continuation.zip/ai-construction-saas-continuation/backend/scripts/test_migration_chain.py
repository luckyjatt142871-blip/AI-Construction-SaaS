"""PostgreSQL-only smoke test; execute on a disposable database with migrator credentials.

Exercises a fresh migration chain, historical upgrade, RLS metadata and trigger behavior.
Never run against a production database.
"""
import os
import subprocess
import sys
from sqlalchemy import create_engine, text

url = os.environ.get('MIGRATION_TEST_DATABASE_URL')
if not url or os.environ.get('ALLOW_DISPOSABLE_MIGRATION_TEST') != 'yes':
    sys.exit('Requires MIGRATION_TEST_DATABASE_URL and ALLOW_DISPOSABLE_MIGRATION_TEST=yes')
if not url.startswith('postgresql+'):
    sys.exit('PostgreSQL required')

env = dict(os.environ, DATABASE_URL=url)

def alembic(*args):
    subprocess.run([sys.executable, '-m', 'alembic', *args], env=env, check=True)

engine = create_engine(url)
with engine.connect() as conn:
    count = conn.execute(text("SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_name NOT LIKE 'pg_%'")).scalar_one()
    if count:
        sys.exit('Refusing to modify non-empty database')

alembic('upgrade', '0003')
with engine.connect() as conn:
    assert 'page_number' not in {r[0] for r in conn.execute(text("SELECT column_name FROM information_schema.columns WHERE table_name='measurements'"))}
    assert 'rate_date' not in {r[0] for r in conn.execute(text("SELECT column_name FROM information_schema.columns WHERE table_name='rate_items'"))}
alembic('upgrade', 'head')
with engine.begin() as conn:
    for table in ('memberships', 'projects', 'audit_logs', 'drawings', 'measurements', 'rate_items', 'estimates', 'estimate_lines', 'drawing_calibrations', 'schedule_activities', 'schedule_dependencies', 'project_budgets', 'project_cost_entries', 'project_issues', 'project_rfis'):
        row = conn.execute(text('SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE oid=to_regclass(:t)'), {'t':table}).one()
        assert row == (True, True), f'RLS flags: {table}'
    triggers = {r[0] for r in conn.execute(text("SELECT tgname FROM pg_trigger WHERE tgrelid='measurements'::regclass AND NOT tgisinternal"))}
    assert 'measurement_calibration_guard' in triggers
    triggers = {r[0] for r in conn.execute(text("SELECT tgname FROM pg_trigger WHERE tgrelid='drawing_calibrations'::regclass AND NOT tgisinternal"))}
    assert 'calibration_immutable_guard' in triggers
    for table, trigger in (
        ('schedule_activities','schedule_activities_scope'),
        ('schedule_dependencies','schedule_dependencies_scope'),
        ('project_budgets','project_budgets_scope'),
        ('project_cost_entries','project_cost_entries_scope'),
        ('project_issues','project_issues_scope'),
        ('project_rfis','project_rfis_scope'),
    ):
        names = {r[0] for r in conn.execute(text("SELECT tgname FROM pg_trigger WHERE tgrelid=to_regclass(:table) AND NOT tgisinternal"), {'table': table})}
        assert trigger in names, f'Missing project-scope trigger {trigger}'
    for table, trigger in (
        ('estimates', 'approved_estimate_header_guard'),
        ('estimate_lines', 'approved_estimate_lines_guard'),
    ):
        names = {r[0] for r in conn.execute(text("SELECT tgname FROM pg_trigger WHERE tgrelid=to_regclass(:table) AND NOT tgisinternal"), {'table': table})}
        assert trigger in names, f'Missing approval immutability trigger {trigger}'
print('Fresh-to-0003-to-head migration, tenant RLS, scope and approval-trigger checks passed')
