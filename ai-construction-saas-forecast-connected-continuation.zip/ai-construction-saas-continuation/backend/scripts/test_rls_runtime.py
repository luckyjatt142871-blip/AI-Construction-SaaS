"""Adversarial RLS smoke test using a non-owner, NOBYPASSRLS runtime login.
Requires a disposable PostgreSQL database migrated to head. Rolls back all data.
"""
import os
from sqlalchemy import create_engine, text

url = os.environ.get('RLS_TEST_APP_URL')
if not url or os.environ.get('APP_ENV') != 'test':
    raise SystemExit('Requires RLS_TEST_APP_URL and APP_ENV=test')
engine = create_engine(url)
with engine.connect() as conn:
    tx = conn.begin()
    try:
        flags = conn.execute(text('SELECT rolbypassrls, rolsuper FROM pg_roles WHERE rolname=current_user')).one()
        assert flags == (False, False), f'Unsafe application role: {flags}'
        assert conn.execute(text("SELECT count(*) FROM projects")).scalar_one() == 0, 'Missing tenant context must deny project visibility'
        # Companies are intentionally not RLS-scoped; projects must be.
        ids = []
        for name in ('RLS smoke company A', 'RLS smoke company B'):
            ids.append(conn.execute(text('INSERT INTO companies(name) VALUES (:n) RETURNING id'), {'n': name}).scalar_one())
        project_ids = []
        for tenant in ids:
            conn.execute(text("SELECT set_config('app.tenant_id', :t, true)"), {'t': str(tenant)})
            project_ids.append(conn.execute(text('INSERT INTO projects(company_id,name) VALUES (:c,:n) RETURNING id'), {'c': tenant, 'n': 'RLS smoke project'}).scalar_one())
        for i, tenant in enumerate(ids):
            conn.execute(text("SELECT set_config('app.tenant_id', :t, true)"), {'t': str(tenant)})
            visible = conn.execute(text('SELECT id FROM projects ORDER BY id')).scalars().all()
            assert visible == [project_ids[i]], f'Cross-tenant project visibility: {visible}'
            try:
                with conn.begin_nested():
                    conn.execute(text('INSERT INTO projects(company_id,name) VALUES (:c,:n)'), {'c': ids[1-i], 'n': 'RLS forbidden'})
            except Exception:
                pass
            else:
                raise AssertionError('Cross-tenant project INSERT was accepted')
        print('PASS: restricted role, deny-by-default, cross-tenant SELECT and INSERT')
    finally:
        tx.rollback()
